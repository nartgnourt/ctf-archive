import { form_data } from 'sk-form-data'

export const handle = form_data
