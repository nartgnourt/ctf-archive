package main

import (
	"fmt"
	"kcsc-note/config"
	"kcsc-note/models"
	"kcsc-note/routes"
	"log"
	"os"

	_ "github.com/joho/godotenv/autoload"
)

func init() {
	config.ConnectDatabase()

	config.DB.AutoMigrate(&models.User{}, &models.Post{}, &models.Access{})
	var adminUser models.User
	result := config.DB.Where("username = ?", "admin").First(&adminUser)
	if result.Error != nil {
		log.Println("Creating admin user...")
		adminUser = models.User{
			Username: "admin",
		}

		adminPassword := os.Getenv("ADMIN_PASSWORD")
		if adminPassword == "" {
			log.Fatal("ADMIN_PASSWORD environment variable is not set.")
		}

		err := adminUser.HashPassword(adminPassword)
		if err != nil {
			log.Fatal("Failed to hash password:", err)
		}

		result = config.DB.Create(&adminUser)
		if result.Error != nil {
			log.Fatal("Failed to create admin user:", result.Error)
		}

		log.Println("Admin user created successfully!")
	} else {
		log.Println("Admin user already exists, skipping creation.")
	}

	var flagPost models.Post
	result = config.DB.Where("title = ?", "KCSC").First(&flagPost)

	if result.Error != nil {
		log.Println("Creating flag post...")

		flag := os.Getenv("FLAG")
		if flag == "" {
			log.Fatal("FLAG environment variable is not set.")
		}

		flagPost = models.Post{
			Title:     "KCSC",
			Content:   "Congratulations! You found the flag: " + flag,
			UserID:    adminUser.ID,
			IsPrivate: true,
		}

		result = config.DB.Create(&flagPost)
		if result.Error != nil {
			log.Fatal("Failed to create flag post:", result.Error)
		}

		log.Println("Flag post created successfully with ID:", flagPost.ID)
	} else {
		log.Println("Flag post already exists, skipping creation.")
	}
}

func main() {
	r := routes.SetupRouter()
	r.Run(fmt.Sprintf(":%s", os.Getenv("PORT")))
}
