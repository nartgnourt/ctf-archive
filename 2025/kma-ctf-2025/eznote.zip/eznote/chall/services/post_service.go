package services

import (
	"crypto/rand"
	"encoding/base64"
	"kcsc-note/config"
	"kcsc-note/models"
	"time"
)

func CreatePost(title, content string, userID uint, isPrivate bool) (*models.Post, error) {
	post := models.Post{
		Title:     title,
		Content:   content,
		UserID:    userID,
		IsPrivate: isPrivate,
	}
	result := config.DB.Create(&post)
	return &post, result.Error
}

func GetPostByID(postID uint) (*models.Post, error) {
	var post models.Post
	result := config.DB.Preload("User").First(&post, postID)
	return &post, result.Error
}

func GetPublicPosts() ([]models.Post, error) {
	var posts []models.Post
	result := config.DB.Where("is_private = ?", false).Preload("User").Find(&posts)
	return posts, result.Error
}

func GetUserPosts(userID uint) ([]models.Post, error) {
	var posts []models.Post
	result := config.DB.Where("user_id = ?", userID).Preload("User").Find(&posts)
	return posts, result.Error
}

func ValidateAccessCode(postID uint, accessCode string, username string) (bool, error) {
	var access models.Access

	result := config.DB.Where(
		"post_id = ? AND access_code = ? AND expires_at > ? AND is_used = ? AND username = ?",
		postID, accessCode, time.Now(), false, username,
	).First(&access)

	if result.Error != nil {

		result = config.DB.Where(
			"post_id = ? AND access_code = ? AND expires_at > ? AND is_used = ? AND (username = '' OR username IS NULL)",
			postID, accessCode, time.Now(), false,
		).First(&access)

		if result.Error != nil {
			return false, result.Error
		}
	}

	access.IsUsed = true
	config.DB.Save(&access)

	return true, nil
}

func GetUserByUsername(username string) error {
	var user models.User
	result := config.DB.Where("username = ?", username).First(&user)
	return result.Error
}

func GenerateUserSpecificAccessCode(postID uint, customCode string, validHours int, username string) (string, error) {
	access := models.Access{
		PostID:    postID,
		ExpiresAt: time.Now().Add(time.Duration(validHours) * time.Hour),
		Username:  username,
	}

	result := config.DB.Create(&access)
	if result.Error != nil {
		return "", result.Error
	}

	b := make([]byte, 12)
	_, err := rand.Read(b)
	if err != nil {
		return "", err
	}

	var accessCode string
	if customCode != "" {
		accessCode = customCode + "-" + base64.URLEncoding.EncodeToString(b)[:16]
	} else {
		accessCode = base64.URLEncoding.EncodeToString(b)[:16]
	}

	access.AccessCode = accessCode
	updateResult := config.DB.Save(&access)
	if updateResult.Error != nil {
		return "", updateResult.Error
	}

	return accessCode, nil
}
