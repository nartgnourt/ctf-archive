package services

import (
	"crypto/rand"
	"encoding/base64"
	"errors"
	"kcsc-note/config"
	"kcsc-note/models"
	"log"
	"net/url"
	"os"
	"time"

	"github.com/golang-jwt/jwt/v4"
)

const csrfTokenExpiry = 1 * time.Hour

var jwtKey []byte

func init() {
	jwtKey = []byte(os.Getenv("JWT_SECRET_KEY"))
}

type JWTClaim struct {
	Username string
	UserID   uint
	CSRF     string
	jwt.StandardClaims
}

func GenerateJWTWithCSRF(username string, userID uint, csrfToken string) (string, error) {
	expirationTime := time.Now().Add(24 * time.Hour)
	claims := &JWTClaim{
		Username: username,
		UserID:   userID,
		CSRF:     csrfToken,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(jwtKey)
}

func ValidateToken(signedToken string) (*JWTClaim, error) {
	token, err := jwt.ParseWithClaims(
		signedToken,
		&JWTClaim{},
		func(token *jwt.Token) (interface{}, error) {
			return jwtKey, nil
		},
	)
	if err != nil {
		return nil, err
	}
	claims, ok := token.Claims.(*JWTClaim)
	if !ok {
		return nil, errors.New("couldn't parse claims")
	}
	if claims.ExpiresAt < time.Now().Unix() {
		return nil, errors.New("token expired")
	}
	return claims, nil
}

func RegisterUser(username, password string) error {
	var user models.User
	user.Username = username
	err := user.HashPassword(password)
	if err != nil {
		return err
	}
	result := config.DB.Create(&user)
	return result.Error
}

func LoginUser(username, password string) (*models.User, error) {
	var user models.User
	result := config.DB.Where("username = ?", username).First(&user)
	if result.Error != nil {
		return nil, result.Error
	}
	err := user.CheckPassword(password)
	if err != nil {
		return nil, err
	}
	return &user, nil
}

func CreateAuthWithCSRF(username string, userID uint) (string, string, error) {
	csrfToken, err := GenerateCSRFToken()
	if err != nil {
		return "", "", err
	}

	token, err := GenerateJWTWithCSRF(username, userID, csrfToken)
	if err != nil {
		return "", "", err
	}

	return token, csrfToken, nil
}

func ValidateCSRFToken(token string, claims *JWTClaim) bool {
	decodedToken, err := url.QueryUnescape(token)
	if err != nil {
		log.Printf("Failed to decode CSRF token: %v", err)
		return claims.CSRF == token
	}
	return claims.CSRF == decodedToken
}

func GenerateCSRFToken() (string, error) {
	b := make([]byte, 32)
	_, err := rand.Read(b)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(b), nil
}
