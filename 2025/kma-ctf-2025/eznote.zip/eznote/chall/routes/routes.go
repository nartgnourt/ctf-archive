package routes

import (
	"kcsc-note/controllers"
	"kcsc-note/middleware"

	"github.com/gin-gonic/gin"
)

func SetupRouter() *gin.Engine {
	r := gin.Default()

	r.LoadHTMLGlob("templates/*")

	r.GET("/", controllers.Index)
	r.GET("/login", controllers.LoginIndex)
	r.POST("/login", controllers.LoginHandler)

	r.GET("/register", controllers.RegisterIndex)
	r.POST("/register", controllers.RegisterHandler)

	protected := r.Group("/")
	protected.Use(middleware.AuthMiddleware())
	{
		protected.GET("/posts", controllers.GetPostsHandler)
		protected.GET("/post/new", controllers.PostNewIndex)

		protected.GET("/report", controllers.ReportIndex)

		protected.GET("/post/:id", controllers.GetPostHandler)
		protected.GET("/logout", controllers.LogoutHandler)
	}

	api := protected.Group("/api")
	api.Use(middleware.CsrfMiddleware())
	{
		api.POST("/report", controllers.ReportHandler)
		api.POST("/post", controllers.CreatePostHandler)
		api.POST("/post/:id/access-code", controllers.GenerateAccessCodeHandler)
	}

	return r
}
