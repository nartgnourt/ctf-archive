package models

import (
	"time"

	"gorm.io/gorm"
)

type Post struct {
	gorm.Model
	Title      string `json:"title"`
	Content    string `json:"content"`
	UserID     uint
	User       User
	IsPrivate  bool   `json:"is_private" gorm:"default:false"`
	AccessCode string `json:"access_code"`
	Accesses   []Access
}

type Access struct {
	gorm.Model
	PostID     uint
	Username   string    `json:"username"`
	AccessCode string    `json:"access_code" gorm:"default:1337"`
	ExpiresAt  time.Time `json:"expires_at"`
	IsUsed     bool      `json:"is_used" gorm:"default:false"`
}
