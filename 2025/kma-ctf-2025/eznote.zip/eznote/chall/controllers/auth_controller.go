package controllers

import (
	"kcsc-note/services"
	"net/http"

	"github.com/gin-gonic/gin"
)

func RegisterHandler(c *gin.Context) {
	var input struct {
		Username string `form:"username" binding:"required"`
		Password string `form:"password" binding:"required"`
	}

	if err := c.ShouldBind(&input); err != nil {
		c.HTML(http.StatusBadRequest, "register.html", gin.H{
			"error": "Invalid input",
		})
		return
	}

	err := services.RegisterUser(input.Username, input.Password)
	if err != nil {
		c.HTML(http.StatusInternalServerError, "register.html", gin.H{
			"error": "Could not register user",
		})
		return
	}

	c.Redirect(http.StatusFound, "/login")
}

func LoginHandler(c *gin.Context) {
	var input struct {
		Username string `form:"username" binding:"required"`
		Password string `form:"password" binding:"required"`
	}

	if err := c.ShouldBind(&input); err != nil {
		c.HTML(http.StatusBadRequest, "login.html", gin.H{
			"error": "Invalid input",
		})
		return
	}

	user, err := services.LoginUser(input.Username, input.Password)
	if err != nil {
		c.HTML(http.StatusUnauthorized, "login.html", gin.H{
			"error": "Invalid credentials",
		})
		return
	}

	token, csrfToken, err := services.CreateAuthWithCSRF(user.Username, user.ID)
	if err != nil {
		c.HTML(http.StatusInternalServerError, "login.html", gin.H{
			"error": "Could not generate token",
		})
		return
	}

	c.SetCookie("token", token, 3600*24, "/", "", false, false)
	c.SetCookie("csrf_token", csrfToken, 3600, "/", "", false, false)

	c.Redirect(http.StatusFound, "/posts")
}

func LogoutHandler(c *gin.Context) {
	c.SetCookie("token", "", -1, "/", "", false, true)
	c.Redirect(http.StatusFound, "/login")
}
