package controllers

import (
	"kcsc-note/services"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func PostNewIndex(c *gin.Context) {
	c.HTML(200, "post_create.html", nil)
}

func CreatePostHandler(c *gin.Context) {
	userID, _ := c.Get("userID")

	var input struct {
		Title     string `json:"title" binding:"required"`
		Content   string `json:"content" binding:"required"`
		IsPrivate bool   `json:"is_private" default:"false"`
	}

	err := c.ShouldBindJSON(&input)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"success": false,
			"error":   "Invalid input: " + err.Error(),
		})
		return

	}

	post, err := services.CreatePost(input.Title, input.Content, userID.(uint), input.IsPrivate)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"success": false,
			"error":   "Could not create post",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"message": "Post created successfully",
		"post": gin.H{
			"id":         post.ID,
			"title":      post.Title,
			"content":    post.Content,
			"is_private": post.IsPrivate,
			"created_at": post.CreatedAt,
		},
	})
}

func GetPostsHandler(c *gin.Context) {
	userID, _ := c.Get("userID")

	posts, err := services.GetUserPosts(userID.(uint))
	if err != nil {
		c.HTML(http.StatusInternalServerError, "post_list.html", gin.H{
			"error": "Could not fetch posts",
		})
		return
	}

	c.HTML(http.StatusOK, "post_list.html", gin.H{
		"posts": posts,
	})
}

func GetPostHandler(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		c.HTML(http.StatusBadRequest, "error.html", gin.H{
			"error": "Invalid post ID",
		})
		return
	}

	post, err := services.GetPostByID(uint(id))
	if err != nil {
		c.HTML(http.StatusNotFound, "error.html", gin.H{
			"error": "Post not found",
		})
		return
	}

	userID, _ := c.Get("userID")
	username, _ := c.Get("username")
	accessCode := c.Query("code")

	if post.UserID == userID.(uint) || !post.IsPrivate {
		c.HTML(http.StatusOK, "post_detail.html", gin.H{
			"post":    post,
			"isOwner": post.UserID == userID.(uint),
		})
		return
	}

	if accessCode != "" {
		valid, _ := services.ValidateAccessCode(post.ID, accessCode, username.(string))
		if valid {
			c.HTML(http.StatusOK, "post_detail.html", gin.H{
				"post":    post,
				"isOwner": false,
			})
			return
		}
	}

	c.HTML(http.StatusForbidden, "error.html", gin.H{
		"error":       "You don't have permission to view this post",
		"requireCode": true,
		"postID":      post.ID,
	})
}

func GenerateAccessCodeHandler(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid post ID"})
		return
	}

	post, err := services.GetPostByID(uint(id))
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Post not found"})
		return
	}

	userID, _ := c.Get("userID")

	if post.UserID != userID.(uint) {
		c.JSON(http.StatusForbidden, gin.H{"error": "You don't own this post"})
		return
	}

	var input struct {
		ValidHours int    `json:"valid_hours" binding:"required,min=1,max=168"`
		CustomCode string `json:"custom_code" binding:"omitempty,max=10"`
		Username   string `json:"username" binding:"required"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	err = services.GetUserByUsername(input.Username)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid username"})
		return
	}

	code, err := services.GenerateUserSpecificAccessCode(post.ID, input.CustomCode, input.ValidHours, input.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate access code"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"access_code":      code,
		"post_id":          post.ID,
		"for_username":     input.Username,
		"expires_in_hours": input.ValidHours,
	})
}
