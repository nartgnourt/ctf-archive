package controllers

import "github.com/gin-gonic/gin"

func Index(c *gin.Context) {
	c.Redirect(302, "/login")
}

func LoginIndex(c *gin.Context) {
	c.HTML(200, "login.html", nil)
}

func RegisterIndex(c *gin.Context) {
	c.HTML(200, "register.html", nil)
}
