package controllers

import (
	"log"
	"net/http"
	"os/exec"

	"github.com/gin-gonic/gin"
)

func ReportIndex(c *gin.Context) {
	c.HTML(200, "report.html", nil)
}

func ReportHandler(c *gin.Context) {
	url := c.Query("url")
	if url == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "URL is required"})
		return
	}

	log.Printf("Report request received for URL: %s", url)

	exec.Command("/usr/local/bin/node", "/app/bot/bot.js", url).Run()

	c.JSON(http.StatusOK, gin.H{
		"url":     url,
		"message": "Ok",
	})
}
