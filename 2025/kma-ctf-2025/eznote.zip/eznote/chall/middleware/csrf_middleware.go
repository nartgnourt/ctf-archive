package middleware

import (
	"net/http"

	"kcsc-note/services"

	"github.com/gin-gonic/gin"
)

func CsrfMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
			return
		}

		if c.Request.Header.Get("Content-Type") == "" {
			c.Next()
			return
		}

		jwtToken, err := c.Cookie("token")
		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Authentication required"})
			c.Abort()
			return
		}

		claims, err := services.ValidateToken(jwtToken)
		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid authentication token"})
			c.Abort()
			return
		}

		csrfToken := c.Request.Header.Get("X-CSRF-Token")

		if csrfToken == "" {
			c.JSON(http.StatusForbidden, gin.H{"error": "CSRF token missing"})
			c.Abort()
			return
		}

		if !services.ValidateCSRFToken(csrfToken, claims) {
			c.JSON(http.StatusForbidden, gin.H{"error": "Invalid CSRF token"})
			c.Abort()
			return
		}

		c.Next()
	}
}
