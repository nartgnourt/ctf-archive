package middleware

import (
	"kcsc-note/services"
	"net/http"

	"github.com/gin-gonic/gin"
)

func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {

		if _, exist := c.Get("userID"); exist {
			c.Next()
			return
		}

		token, err := c.Cookie("token")
		if err != nil {
			if c.RemoteIP() == "127.0.0.1" || c.RemoteIP() == "::1" {
				token, csrfToken, err := services.CreateAuthWithCSRF("admin", uint(1))
				if err != nil {
					c.Redirect(http.StatusFound, "/login")
					c.Abort()
					return
				}
				c.SetCookie("token", token, 3600*24, "/", "", false, false)
				c.SetCookie("csrf_token", csrfToken, 3600, "/", "", false, false)
				c.Set("username", "admin")
				c.Set("userID", uint(1))
				c.Next()
				return
			}
			c.Redirect(http.StatusFound, "/login")
			c.Abort()
			return
		}

		claims, err := services.ValidateToken(token)
		if err != nil {
			c.SetCookie("token", "", -1, "/", "", false, true)
			c.Redirect(http.StatusFound, "/login")
			c.Abort()
			return
		}

		c.Set("username", claims.Username)
		c.Set("userID", claims.UserID)
		c.Next()
	}
}
