const puppeteer = require('puppeteer');
require('dotenv').config({path: '../.env'});

const targetUrl = process.argv[2];

if (!targetUrl) {
  console.error('Error: Please provide a URL to visit as a command line argument');
  console.error('Usage: node bot.js <url>');
  process.exit(1);
}

const username = process.env.ADMIN_USERNAME || "admin";
const password = process.env.ADMIN_PASSWORD || "43eafc1ac6168d57dbde2a2f48c38402";
const host     = process.env.HOST || "localhost"; 
const port     = process.env.PORT || "19101"; 
if (!password) {
  console.error('Error: ADMIN_PASSWORD environment variable is not set');
  process.exit(1);
}

(async () => {
  console.log('Starting browser...');
  const browser = await puppeteer.launch({
    headless: 'new',
    pipe: true,
    args: [
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-gpu',
        '--disable-default-apps',
        '--no-sandbox',
        '--disable-setuid-sandbox',
    ]
});

  try {
    const page = await browser.newPage();
    console.log('Browser started successfully');
    
    page.setDefaultNavigationTimeout(30000);

    console.log(`Navigating to target URL: ${targetUrl}`);
    await page.goto(targetUrl, { waitUntil: 'networkidle2' });

    console.log('Target page loaded successfully');

  } catch (error) {
    console.error('An error occurred:', error);
  } finally {
    console.log('Closing browser...');
    await browser.close();
    console.log('Browser closed');
  }
})();