package ctf.kcsc.legacy;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.util.Base64;

@RestController
@RequestMapping("/legacy")
public class Controller {

    @GetMapping("/msg")
    public String genMsg() {
        return Legacy.genMsg();
    }

    @ResponseBody
    @RequestMapping(value = "/deser", method = RequestMethod.POST)
    public String deser(@RequestParam("data") String data) {
        try {
            byte[] decodedData = Base64.getDecoder().decode(data);
            try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(decodedData))) {
                ois.readObject().toString();
            }
            return "Done";
        } catch (Exception e) {
            throw new RuntimeException("Deserialization failed: " + getFullStackTrace(e));
        }
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public String handleException(Exception e) {
        return "Error:\n" + getFullStackTrace(e);
    }

    private String getFullStackTrace(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }
}
