package ctf.kcsc.legacy;

import java.util.Random;

public class Legacy {
    private static final String[] MESSAGES = {
            "System boot sequence initialized...",
            "Loading legacy kernel modules...",
            "Connection to mainframe established.",
            "Warning: Deprecated API in use.",
            "Memory allocation successful, 64KB reserved.",
            "Error: Stack overflow detected!",
            "Legacy mode activated.",
            "Authenticating user... Access granted.",
            "Initializing vintage protocol stack...",
            "Operation completed with minor warnings."
    };

    public Legacy() { }

    public static String genMsg() {
        return MESSAGES[new Random().nextInt(MESSAGES.length)];
    }
}
