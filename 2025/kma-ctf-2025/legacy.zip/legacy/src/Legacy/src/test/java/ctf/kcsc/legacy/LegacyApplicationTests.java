package ctf.kcsc.legacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LegacyApplicationTests {

    @Test
    void contextLoads() {
    }

}
