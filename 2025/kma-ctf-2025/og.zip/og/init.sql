CREATE DATABASE IF NOT EXISTS og_db;
USE og_db;

-- Create the table
CREATE TABLE users (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (username, email) VALUES
    ('john', 'john@mail.com'),
    ('alice', 'alice@mail.com'),
    ('bob', 'bob@mail.com'),
    ('peter', 'peter@mail.com'),
    ('tony', 'tony@mail.com'),
    ('kcsc', 'kcsc@mail.com'),
    ('endy', 'endy@mail.com');

CREATE USER IF NOT EXISTS 'dbuser'@'%' IDENTIFIED BY 'dbpassword';
GRANT ALL PRIVILEGES ON og_db.* TO 'dbuser'@'%';
FLUSH PRIVILEGES;