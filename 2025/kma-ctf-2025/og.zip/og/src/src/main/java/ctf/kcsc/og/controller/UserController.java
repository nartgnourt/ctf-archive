package ctf.kcsc.og.controller;

import ctf.kcsc.og.model.User;
import ctf.kcsc.og.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable long id) {
        return userService.getUserById(id);
    }

    @GetMapping("/search")
    public List<User> searchByUsername(@RequestParam String username) {
        if (username != null && username.length() >= 1000) {
            throw new IllegalArgumentException("What's wrong with your username?");
        }
        return userService.getByUsername(username);
    }
}
