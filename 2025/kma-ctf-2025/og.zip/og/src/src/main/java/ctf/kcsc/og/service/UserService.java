package ctf.kcsc.og.service;

import ctf.kcsc.og.mapper.UserMapper;
import ctf.kcsc.og.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public List<User> getAllUsers() {
        return userMapper.findAll();
    }

    public List<User> getByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    public User getUserById(long id) {
        return userMapper.findById(id);
    }

}
