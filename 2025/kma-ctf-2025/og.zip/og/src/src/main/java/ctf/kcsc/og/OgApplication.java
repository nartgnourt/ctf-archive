package ctf.kcsc.og;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OgApplication {

    public static void main(String[] args) {
        SpringApplication.run(OgApplication.class, args);
    }

}
