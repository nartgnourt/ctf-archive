package ctf.kcsc.og.mapper;

import ctf.kcsc.og.model.User;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.jdbc.SQL;
import java.util.List;

@Mapper
public interface UserMapper {

    @SelectProvider(type = UserSqlProvider.class, method = "findAll")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "username", column = "username"),
            @Result(property = "email", column = "email"),
            @Result(property = "createdAt", column = "created_at")
    })
    List<User> findAll();

    @SelectProvider(type = UserSqlProvider.class, method = "findById")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "username", column = "username"),
            @Result(property = "email", column = "email"),
            @Result(property = "createdAt", column = "created_at")
    })
    User findById(Long id);

    @SelectProvider(type = UserSqlProvider.class, method = "findByUsername")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "username", column = "username"),
            @Result(property = "email", column = "email"),
            @Result(property = "createdAt", column = "created_at")
    })
    List<User> findByUsername(String username);

    class UserSqlProvider {
        public String findAll() {
            return new SQL() {{
                SELECT("*");
                FROM("users");
            }}.toString();
        }
        public String findById(Long id) {
            return new SQL() {{
                SELECT("*");
                FROM("users");
                WHERE("id = " + id);
            }}.toString();
        }
        public String findByUsername(String username) {
            return new SQL() {{
                SELECT("*");
                FROM("users");
                WHERE("username LIKE CONCAT('%','"+username+"', '%')");
            }}.toString();
        }
    }
}