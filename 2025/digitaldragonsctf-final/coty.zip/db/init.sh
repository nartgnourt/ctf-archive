#!/bin/bash

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" << EOF
    CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT ON TABLES TO $DB_USER;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO $DB_USER;

    GRANT EXECUTE ON FUNCTION pg_ls_dir(text) TO $DB_USER;
    GRANT EXECUTE ON FUNCTION pg_read_file(text) TO $DB_USER;
    GRANT pg_read_server_files TO $DB_USER;


    CREATE TABLE IF NOT EXISTS cats(
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        breed VARCHAR(255) NOT NULL,
        image VARCHAR(255) NOT NULL,
        age INT NOT NULL,
        color VARCHAR(255) NOT NULL,
        description TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ratings(
        id SERIAL PRIMARY KEY,
        cat_id INT NOT NULL,
        rating INT NOT NULL,
        FOREIGN KEY (cat_id) REFERENCES cats(id)    
    );

    INSERT INTO cats (name, breed, image, age, color, description) VALUES
    ('Whiskers', 'Persian', 'https://i.pinimg.com/736x/b4/bb/b2/b4bbb2198b036fe1024571ec6b60f8b8.jpg', 3, 'White', 'A fluffy and adorable Persian cat with beautiful white fur'),
    ('Shadow', 'British Shorthair', 'https://media.tenor.com/fFk0pXFySvkAAAAe/shadow-cat-very-sad.png', 2, 'Gray', 'A playful gray cat who loves to hide in shadows and surprise people'),
    ('Mittens', 'Maine Coon', 'https://www.worldsbestcatlitter.com/wp-content/uploads/2019/12/02_coughing-cat-meme.jpg', 4, 'Orange', 'A large and gentle Maine Coon with distinctive white paws like mittens'),
    ('Luna', 'Siamese', 'https://media.tenor.com/GUdP15h5ewEAAAAe/catzaza-cat.png', 1, 'Cream', 'A graceful Siamese cat with striking blue eyes and a sleek coat'),
    ('Snowy', 'Siberian', 'https://preview.redd.it/post-the-best-cat-memes-you-got-in-the-comments-please-v0-kg82lbnu0ste1.png?auto=webp&s=e6f9eee86484f5de3f4e31f3c33b2d07fb982bd5', 1, 'White', 'A young and energetic Siberian cat with striking white fur'),
    ('Black', 'Siberian', 'https://uploads.dailydot.com/2024/07/side-eye-cat.jpg?q=65&auto=format&w=1600&ar=2:1&fit=crop', 1, 'Black', 'A young and energetic Siberian cat with striking black fur');
    
    INSERT INTO ratings (cat_id, rating) VALUES
    (1, 5), (2, 4), (3, 3), (4, 2), (5, 1), (6, 5);
EOF