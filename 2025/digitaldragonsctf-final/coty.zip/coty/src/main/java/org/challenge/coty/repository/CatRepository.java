package org.challenge.coty.repository;

import org.challenge.coty.entity.Cat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CatRepository extends JpaRepository<Cat, Long> {

    public List<Cat> findAll();

    @Query(value = """
            SELECT c.id, c.name, c.breed, c.image, c.age, c.color, c.description,
                   COALESCE(ROUND(AVG(r.rating::decimal), 2), 0) as avg_rating,
                   COUNT(r.rating) as total_ratings
            FROM cats c
            LEFT JOIN ratings r ON c.id = r.cat_id
            GROUP BY c.id, c.name, c.breed, c.image, c.age, c.color, c.description
            ORDER BY avg_rating DESC, c.name
            """, nativeQuery = true)
    public List<Cat> findAllWithAverageRating();

    public Optional<Cat> findByNameIgnoreCase(String name);
}
