package org.challenge.coty.controller;

import java.util.Optional;

import org.challenge.coty.entity.Cat;
import org.challenge.coty.entity.Rating;
import org.challenge.coty.repository.CatRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class CatController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CatController.class);

    @Autowired
    private CatRepository catRepository;
    
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("cats", catRepository.findAll());
        LOGGER.info("Showing all cats for rating");
        return "index";
    }
    
    @GetMapping("/cat")
    public String details(@RequestParam(value = "name", required = false, defaultValue = "whiskers") String catName, Model model) {
        Optional<Cat> cat = catRepository.findByNameIgnoreCase(catName);
        if (cat.isPresent()) {
            model.addAttribute("cat", cat.get());
        } 

        model.addAttribute("catName", catName);
        return "details";
    }
    
    @PostMapping(value = "/rating")
    public String submitRating(@RequestParam(value = "name", required = false, defaultValue = "whiskers") String catName, 
                                             @RequestParam int stars,
                                             RedirectAttributes redirectAttributes,
                                             Model model) {
        
        Optional<Cat> cat = catRepository.findByNameIgnoreCase(catName.trim());
        if (cat.isPresent()) {
            cat.get().getRatings().add(new Rating(stars, cat.get()));
            catRepository.save(cat.get());
            redirectAttributes.addFlashAttribute("message",
                    "Thank you for rating. Pray for your cat to win the contest!");

            return "redirect:/cat?name=" + catName;
        } 

        redirectAttributes.addFlashAttribute("message", "Cat not found, cannot rate.");
        return "redirect:/cat";
    }
} 