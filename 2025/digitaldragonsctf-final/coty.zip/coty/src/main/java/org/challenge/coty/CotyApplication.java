package org.challenge.coty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CotyApplication {

    public static void main(String[] args) {
        SpringApplication.run(CotyApplication.class, args);
    }
}
