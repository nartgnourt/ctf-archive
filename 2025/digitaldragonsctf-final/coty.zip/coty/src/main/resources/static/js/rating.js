document.addEventListener('DOMContentLoaded', function() {
    const stars = document.querySelectorAll('.star-label');
    const inputs = document.querySelectorAll('.star-input');
    const ratingValue = document.getElementById('ratingValue');
    const submitBtn = document.getElementById('submitBtn');
    let currentRating = 0;

    const ratingTexts = {
        1: "😐",
        2: "🙂",
        3: "😊",
        4: "😍",
        5: "🥰"
    };

    function resetStars() {
        stars.forEach(star => {
            star.classList.remove('active');
        });
    }

    function lightUpStars(rating) {
        resetStars();
        for (let i = 0; i < rating; i++) {
            stars[i].classList.add('active');
        }
    }

    stars.forEach((star, index) => {
        const rating = index + 1;

        star.addEventListener('mouseenter', function() {
            lightUpStars(rating);
            ratingValue.textContent = ratingTexts[rating];
        });

        star.addEventListener('click', function() {
            currentRating = rating;
            inputs[index].checked = true;
            lightUpStars(rating);
            ratingValue.textContent = ratingTexts[rating];
            submitBtn.disabled = false;
            submitBtn.style.background = 'linear-gradient(135deg, #ffd700, #ffed4e)';
            submitBtn.style.color = '#021526';
        });
    });

    document.querySelector('.star-rating').addEventListener('mouseleave', function() {
        if (currentRating > 0) {
            lightUpStars(currentRating);
            ratingValue.textContent = ratingTexts[currentRating];
        } else {
            resetStars();
            ratingValue.textContent = "Click on stars to rate!";
        }
    });

    document.getElementById('ratingForm').addEventListener('submit', function(e) {
        if (currentRating === 0) {
            e.preventDefault();
            alert('Please select a rating before submitting!');
            return false;
        }
    });
});