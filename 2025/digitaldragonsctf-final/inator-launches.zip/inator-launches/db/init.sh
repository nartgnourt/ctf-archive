#!/bin/bash

psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" << EOF
    DROP USER IF EXISTS $DATASOURCE_USERNAME;
    CREATE USER $DATASOURCE_USERNAME WITH PASSWORD '$DATASOURCE_PASSWORD';

    CREATE TABLE IF NOT EXISTS inators (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        image_url TEXT,
        release_date DATE
    );

    CREATE TABLE IF NOT EXISTS registrations (
        id SERIAL PRIMARY KEY,
        inator_id INTEGER NOT NULL,
        name VARCHAR(120) NOT NULL,
        email VARCHAR(180) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    INSERT INTO inators (name, description, image_url, release_date) VALUES
        ('Destruct-inator', 'Because of humiliation back in his childhood years, I gathered all the lawn gnomes in the Tri-State Area and plans to destroy them.', 'https://static.wikia.nocookie.net/new-smash-bros-lawl-origin/images/c/cf/SelfDestructButton.png', '2025-10-30'),
        ('Giant Building Rotator', 'A giant robot in an attempt to take over the Tri-State Area.', 'https://64.media.tumblr.com/3b9c19bd85287d0bd371b347cb7ff9a2/ad3a2956f96fa20b-0d/s1280x1920/a0541f62635fbd3e466337d502f9b6d9ddff269b.png', '2025-03-08'),
        ('Smell-inator', 'Doof, not realizing it, accidentally puts in a growth formula that fell into his hands after Blanca Dishon and P. P. Otter had a fight over it, and a hit against the machine after he put the formula into it causes it to enlarge the entire universe.', 'https://www.blogs.unicamp.br/zero/wp-content/uploads/sites/187/2021/01/2021-01-27-172408_1366x768_scrot.png', '2025-12-12'),
        ('Turn-Everything-Evil-inator', 'A ray that can turn anything, starting with Agent P, into his evil minion.', 'https://www.blogs.unicamp.br/zero/wp-content/uploads/sites/187/2020/05/2020-05-22-134946_1366x768_scrot.png', '2025-08-08');

    GRANT CONNECT ON DATABASE $POSTGRES_DB TO $DATASOURCE_USERNAME;
    GRANT USAGE ON SCHEMA public TO $DATASOURCE_USERNAME;
    
    GRANT SELECT ON inators TO $DATASOURCE_USERNAME;
    GRANT SELECT, INSERT ON registrations TO $DATASOURCE_USERNAME;
    GRANT USAGE, SELECT ON SEQUENCE registrations_id_seq TO $DATASOURCE_USERNAME;
EOF
