// Empty file to prevent preview script errors
// This ensures the preview system doesn't interfere with our application
