
DROP TABLE orders;
DROP TABLE teas;
