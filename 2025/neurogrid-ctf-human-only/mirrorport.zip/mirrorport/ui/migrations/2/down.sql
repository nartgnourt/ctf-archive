
DELETE FROM teas WHERE name IN (
  '龍井茶 (Longjing Tea)',
  '鉄観音 (Tie Guan Yin)', 
  '白毫銀針 (Silver Needle)',
  '普洱茶 (Pu-erh)',
  '茉莉花茶 (Jasmine)'
);
