#!/bin/bash

echo "Stopping ashenvault application..."

# Stop the container
echo "Stopping container..."
docker stop ashenvault-container 2>/dev/null || echo "Container not running"

# Remove the container
echo "Removing container..."
docker rm ashenvault-container 2>/dev/null || echo "Container not found"

echo "ashenvault application stopped and cleaned up!"
