ENABLE_REMOTE_UPDATER = False
USERNAME = 'u'
PASSWORD = 'p'

BANNED_USER_IDS: list[str] = [
]

# set to None or empty string to disable
WEBHOOK = ''