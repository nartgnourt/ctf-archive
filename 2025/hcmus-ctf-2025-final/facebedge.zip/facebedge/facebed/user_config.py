ENABLE_REMOTE_UPDATER = False
USERNAME = '[REDACTED]'
PASSWORD = '[REDACTED]'
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123 Safari/537.3"

BANNED_USER_IDS: list[str] = [
]

# set to None or empty string to disable
WEBHOOK = ''