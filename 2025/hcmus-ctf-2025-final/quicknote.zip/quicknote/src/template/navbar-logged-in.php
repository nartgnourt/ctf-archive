<div class="d-flex align-items-center">
    <span class="text-white me-3">
        <i class="fas fa-user-circle me-1"></i>
        Welcome, <?php echo $username; ?>!
    </span>
    <a href="logout.php" class="btn btn-outline-light btn-sm">
        <i class="fas fa-sign-out-alt me-1"></i>Logout
    </a>
</div>