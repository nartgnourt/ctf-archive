<div class="main-content error">
    <div class="error-card card">
        <div class="card-body p-5">
            <i class="fas fa-exclamation-triangle fa-4x mb-4" style="color: #000000;"></i>
            <h2 class="card-title mb-3">Note Not Found</h2>
            <p class="card-text mb-4">The requested note could not be found or the file is invalid.</p>
            <a href="index.php" class="btn btn-primary-custom btn-lg">
                <i class="fas fa-home me-2"></i>Back to QuickNote
            </a>
        </div>
    </div>
</div>