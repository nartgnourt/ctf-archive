<button class="btn btn-login" onclick="openLoginModal()">
    <i class="fas fa-sign-in-alt me-2"></i>Login
</button>