#!/bin/bash

echo "Building PeppermintRoute CTF Challenge..."
echo "=========================================="

# Build the Docker container
docker-compose build

if [ $? -eq 0 ]; then
    echo ""
    echo "Build successful!"
    echo ""
    echo "To start the challenge, run:"
    echo "  docker-compose up -d"
    echo ""
    echo "Access the application at: http://127.0.0.1:1337"
    echo ""
    echo "Default credentials:"
    echo "  Admin:  admin / santaclaus"
    echo "  Pilot:  rudolph / pilot123"
else
    echo ""
    echo "Build failed! Check the error messages above."
    exit 1
fi
