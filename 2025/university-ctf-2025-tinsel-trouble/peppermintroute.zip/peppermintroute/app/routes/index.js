const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');

const publicController = require('../controllers/publicController');
const authController = require('../controllers/authController');
const userController = require('../controllers/userController');
const adminController = require('../controllers/adminController');
const fileController = require('../controllers/fileController');
const apiController = require('../controllers/apiController');
const Recipient = require('../models/Recipient');

const storage = multer.diskStorage({
    destination: async function (req, file, cb) {

        let uploadPath;

        if (req.params && req.params.recipient) {
            const recipientDir = await Recipient.getDirectory(req.params.recipient);
            if (recipientDir) {
                uploadPath = recipientDir;
            } else {
                return cb(new Error('Recipient not found'));
            }
        } 

        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }

        cb(null, uploadPath);
    },
    filename: function (_req, file, cb) {
        const fileId = crypto.randomBytes(16).toString('hex');
        file.fileId = fileId;
        cb(null, file.originalname);
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024,
        files: 10
    },
    fileFilter: function(req, file, cb) {
        cb(null, true);
    }
});

// PUBLIC ROUTES
router.get('/', publicController.getIndex);
router.get('/login', authController.getLogin);
router.post('/login', authController.postLogin);
router.get('/logout', authController.logout);
router.get('/api/user', apiController.getCurrentUser);
router.get('/api/public-stats', apiController.getPublicStats);

// USER-LEVEL
router.get('/api/user/dashboard-data', authController.requireAuth, authController.requireUser, apiController.getUserDashboardData);
router.get('/api/user/packages-data', authController.requireAuth, authController.requireUser, apiController.getUserPackagesData);
router.get('/api/user/package/:recipient', authController.requireAuth, authController.requireUser, apiController.getPackageDetailData);
router.get('/user/dashboard', authController.requireAuth, authController.requireUser, userController.getDashboard);
router.get('/user/packages', authController.requireAuth, authController.requireUser, userController.getPackages);
router.post('/user/packages/pickup', authController.requireAuth, authController.requireUser, userController.pickupPackage);
router.get('/user/package/:recipient', authController.requireAuth, authController.requireUser, fileController.viewPackage);
router.get('/user/packages/:recipient/download', authController.requireAuth, authController.requireUser, fileController.downloadAttachment);

// ADMIN-LEVEL
router.get('/api/admin/dashboard-data', authController.requireAuth, authController.requireAdmin, apiController.getAdminDashboardData);
router.get('/api/admin/recipients-data', authController.requireAuth, authController.requireAdmin, apiController.getRecipientsData);
router.get('/api/admin/pilots-data', authController.requireAuth, authController.requireAdmin, apiController.getPilotsData);
router.get('/api/admin/pilot/:username', authController.requireAuth, authController.requireAdmin, apiController.getPilotDetailData);
router.get('/api/admin/package/:recipient', authController.requireAuth, authController.requireAdmin, apiController.getAdminPackageDetailData);
router.get('/admin/dashboard', authController.requireAuth, authController.requireAdmin, adminController.getDashboard);
router.get('/admin/recipient-management', authController.requireAuth, authController.requireAdmin, adminController.getRecipientManagement);
router.post('/admin/recipient-management/create', authController.requireAuth, authController.requireAdmin, adminController.createRecipient);
router.get('/admin/pilots', authController.requireAuth, authController.requireAdmin, adminController.getPilots);
router.get('/admin/pilots/:username', authController.requireAuth, authController.requireAdmin, adminController.getPilotDetail);
router.get('/admin/recipients/:recipient', authController.requireAuth, authController.requireAdmin, adminController.getPackageDetail);
router.post('/admin/recipients/:recipient/create-package', authController.requireAuth, authController.requireAdmin, adminController.createPackageFromForm);
router.post('/admin/recipients/:recipient/upload', authController.requireAuth, authController.requireAdmin, upload.array('files'), adminController.uploadFiles);
router.post('/admin/recipients/:recipient/assign', authController.requireAuth, authController.requireAdmin, adminController.assignPackage);

module.exports = router;
