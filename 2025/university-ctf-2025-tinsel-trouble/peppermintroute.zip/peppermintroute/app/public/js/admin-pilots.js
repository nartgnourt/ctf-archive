// Admin pilots page functionality

(async () => {
    const authResult = await Auth.checkAuth('admin');
    if (!authResult) return;
    Auth.renderNavigation(authResult.user);

    try {
        const response = await fetch('/api/admin/pilots-data');
        const data = await response.json();
        const tbody = document.getElementById('pilots-tbody');
        const countBadge = document.getElementById('pilot-count');

        countBadge.textContent = `${data.pilots.length} pilots`;

        if (data.pilots.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-state">No pilots registered yet</td></tr>';
        } else {
            let html = '';
            data.pilots.forEach(pilot => {
                html += `<tr>`;
                html += `<td><strong>${escapeHtml(pilot.username)}</strong></td>`;
                html += `<td>${escapeHtml(pilot.destination || 'N/A')}</td>`;
                html += `<td>${pilot.active_deliveries || 0}</td>`;
                html += `<td><a href="/admin/pilots/${encodeURIComponent(pilot.username)}" class="action-btn">View Details</a></td>`;
                html += `</tr>`;
            });
            tbody.innerHTML = html;
        }
    } catch (error) {
        console.error('Error loading pilots:', error);
        document.getElementById('pilots-tbody').innerHTML = '<tr><td colspan="4" class="empty-state">Error loading pilots</td></tr>';
    }
})();
