// User packages page functionality

function renderMyPackages(packages) {
    const container = document.getElementById('my-packages-container');

    if (!packages || packages.length === 0) {
        container.innerHTML = '<p class="no-data">You don\'t have any active deliveries. Pick up a package below to start delivering!</p>';
        return;
    }

    let html = '<table class="data-table"><thead><tr>';
    html += '<th>Recipient</th><th>Destination</th><th>Status</th><th>Actions</th>';
    html += '</tr></thead><tbody>';

    packages.forEach(pkg => {
        html += '<tr>';
        html += `<td><strong>${escapeHtml(pkg.recipient)}</strong></td>`;
        html += `<td><span class="coordinates">${pkg.dest_lat.toFixed(4)}, ${pkg.dest_lon.toFixed(4)}</span></td>`;
        html += `<td><span class="badge badge-${pkg.status}">${escapeHtml(pkg.status)}</span></td>`;
        html += `<td><a href="/user/package/${encodeURIComponent(pkg.recipient)}" class="btn btn-sm btn-primary">View Details</a></td>`;
        html += '</tr>';
    });

    html += '</tbody></table>';
    container.innerHTML = html;
}

function renderAvailablePackages(packages) {
    const container = document.getElementById('available-packages-container');

    if (!packages || packages.length === 0) {
        container.innerHTML = '<p class="no-data">No packages available at the moment.</p>';
        return;
    }

    let html = '<table class="data-table"><thead><tr>';
    html += '<th>Recipient</th><th>Source</th><th>Destination</th><th>Distance</th><th>Actions</th>';
    html += '</tr></thead><tbody>';

    packages.forEach(pkg => {
        const distance = calculateDistance(pkg.source_lat, pkg.source_lon, pkg.dest_lat, pkg.dest_lon);
        html += '<tr>';
        html += `<td><strong>${escapeHtml(pkg.recipient)}</strong></td>`;
        html += `<td><span class="coordinates">${pkg.source_lat.toFixed(4)}, ${pkg.source_lon.toFixed(4)}</span></td>`;
        html += `<td><span class="coordinates">${pkg.dest_lat.toFixed(4)}, ${pkg.dest_lon.toFixed(4)}</span></td>`;
        html += `<td>${distance} km</td>`;
        html += `<td><form action="/user/packages/pickup" method="POST" style="display: inline;">`;
        html += `<input type="hidden" name="recipient" value="${escapeHtml(pkg.recipient)}">`;
        html += `<button type="submit" class="btn btn-sm btn-success">Pick Up</button>`;
        html += `</form></td>`;
        html += '</tr>';
    });

    html += '</tbody></table>';
    container.innerHTML = html;
}

(async () => {
    const authResult = await Auth.checkAuth('user');
    if (!authResult) return;

    Auth.renderNavigation(authResult.user);
    document.getElementById('username').textContent = authResult.user.username;

    try {
        const response = await fetch('/api/user/packages-data');
        const data = await response.json();

        console.log('[BROWSER] Loaded packages:', data.myPackages, data.availablePackages);
        data.myPackages?.forEach(pkg => {
            console.log(`[BROWSER] Package ${pkg.recipient}: lat=${pkg.dest_lat}, lon=${pkg.dest_lon}`);
        });
        data.availablePackages?.forEach(pkg => {
            console.log(`[BROWSER] Available ${pkg.recipient}: lat=${pkg.dest_lat}, lon=${pkg.dest_lon}`);
        });

        renderMyPackages(data.myPackages);
        renderAvailablePackages(data.availablePackages);
    } catch (error) {
        console.error('Error loading packages:', error);
        document.getElementById('my-packages-container').innerHTML = '<p class="no-data">Error loading packages</p>';
        document.getElementById('available-packages-container').innerHTML = '<p class="no-data">Error loading packages</p>';
    }
})();
