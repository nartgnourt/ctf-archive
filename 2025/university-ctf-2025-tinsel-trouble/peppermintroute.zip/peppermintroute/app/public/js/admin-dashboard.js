// Admin dashboard functionality

(async () => {
    const authResult = await Auth.checkAuth('admin');
    if (!authResult) return;

    Auth.renderNavigation(authResult.user);

    try {
        const response = await fetch('/api/admin/dashboard-data');
        const data = await response.json();

        document.getElementById('total-pilots').textContent = data.totalPilots || 0;
        document.getElementById('total-packages').textContent = data.totalPackages || 0;
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
})();
