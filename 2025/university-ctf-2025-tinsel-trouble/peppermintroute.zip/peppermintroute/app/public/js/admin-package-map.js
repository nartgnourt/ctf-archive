
document.addEventListener('DOMContentLoaded', function() {
    if (typeof packageData !== 'undefined' && packageData) {
        setTimeout(() => initializeMap(packageData), 100);
    }
});

function initializeMap(data) {
    const canvas = document.getElementById('trackingMap');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    const mapWidth = canvas.width;
    const mapHeight = canvas.height;

    const tileSize = 256;

    const DISTRIBUTION_CENTER = {
        name: "Oslo Distribution Center",
        lat: 59.9139,
        lon: 10.7522
    };

    // Hardcoded waypoints
    const HARDCODED_WAYPOINTS = [
        {lat: 61.1776, lon: 25.7257, name: "Norway Checkpoint"},
        {lat: 60.1695, lon: 24.9354, name: "Helsinki Waypoint"}
    ];

    data.source = {
        name: DISTRIBUTION_CENTER.name,
        coordinates: {
            lat: DISTRIBUTION_CENTER.lat,
            lon: DISTRIBUTION_CENTER.lon
        }
    };

    let waypoints = [];

    waypoints.push({
        lat: DISTRIBUTION_CENTER.lat,
        lon: DISTRIBUTION_CENTER.lon,
        name: DISTRIBUTION_CENTER.name
    });

    waypoints = waypoints.concat(HARDCODED_WAYPOINTS);

    if (data.destination && data.destination.coordinates) {
        console.log(`[MAP] Adding destination to waypoints: lat=${data.destination.coordinates.lat}, lon=${data.destination.coordinates.lon}`);
        waypoints.push({
            lat: data.destination.coordinates.lat,
            lon: data.destination.coordinates.lon,
            name: data.destination.name || data.destination.city || 'Destination'
        });
    }

    console.log('[MAP] Final waypoints array:', waypoints);

    const sleighFinalPos = getCurrentPosition(waypoints, 1.0);
    const destPinPos = waypoints[waypoints.length - 1];
    console.log('========================================');
    console.log('[SLEIGH FINAL DESTINATION] When animation completes (progress=1.0):');
    console.log(`  Lat: ${sleighFinalPos.lat}, Lon: ${sleighFinalPos.lon}`);
    console.log('[RED PIN LOCATION] Where destination pin is drawn:');
    console.log(`  Lat: ${destPinPos.lat}, Lon: ${destPinPos.lon}, Name: ${destPinPos.name}`);
    console.log('========================================');

    if (!data.route) {
        data.route = {};
    }
    data.route.waypoints = waypoints;
    const bounds = calculateBounds(waypoints);

    let zoom = calculateOptimalZoom(bounds, mapWidth, mapHeight);

    const clampedMinLat = Math.max(-85.0511, Math.min(85.0511, bounds.minLat));
    const clampedMaxLat = Math.max(-85.0511, Math.min(85.0511, bounds.maxLat));

    let centerLat = (clampedMaxLat + clampedMinLat) / 2;

    if (clampedMaxLat > 80) {
        const latRange = clampedMaxLat - clampedMinLat;
        centerLat = centerLat - (latRange * 0.15);
    }

    let centerLon = (bounds.maxLon + bounds.minLon) / 2;
    let isDragging = false;
    let lastX = 0;
    let lastY = 0;
    let velocity = { x: 0, y: 0 };

    let currentProgress = 0;
    const animationSpeed = 0.00005;

    const tileCache = new Map();

    function calculateBounds(waypoints) {
        let minLat = waypoints[0].lat;
        let maxLat = waypoints[0].lat;
        let minLon = waypoints[0].lon;
        let maxLon = waypoints[0].lon;

        waypoints.forEach(wp => {
            minLat = Math.min(minLat, wp.lat);
            maxLat = Math.max(maxLat, wp.lat);
            minLon = Math.min(minLon, wp.lon);
            maxLon = Math.max(maxLon, wp.lon);
        });

        return { minLat, maxLat, minLon, maxLon };
    }

    function calculateOptimalZoom(bounds, width, height) {
        const ZOOM_MAX = 18;

        const clampedMinLat = Math.max(-85.0511, Math.min(85.0511, bounds.minLat));
        const clampedMaxLat = Math.max(-85.0511, Math.min(85.0511, bounds.maxLat));

        const lonRange = bounds.maxLon - bounds.minLon;

        for (let z = ZOOM_MAX; z >= 1; z--) {
            const n = Math.pow(2, z);

            const minLatRad = clampedMinLat * Math.PI / 180;
            const maxLatRad = clampedMaxLat * Math.PI / 180;
            const minY = (1 - Math.log(Math.tan(minLatRad) + 1 / Math.cos(minLatRad)) / Math.PI) / 2 * n;
            const maxY = (1 - Math.log(Math.tan(maxLatRad) + 1 / Math.cos(maxLatRad)) / Math.PI) / 2 * n;
            const latTileSpan = Math.abs(maxY - minY);

            const lonTileSpan = (lonRange / 360) * n;

            const latPixelSpan = latTileSpan * tileSize;
            const lonPixelSpan = lonTileSpan * tileSize;

            const paddingFactor = 0.7;
            if (latPixelSpan < height * paddingFactor && lonPixelSpan < width * paddingFactor) {
                return z;
            }
        }

        return 2;
    }

    function loadTile(x, y, z) {
        const key = `${z}/${x}/${y}`;
        if (tileCache.has(key)) {
            return tileCache.get(key);
        }

        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;

        const tile = { img, loaded: false };
        tileCache.set(key, tile);

        img.onload = () => {
            tile.loaded = true;
        };

        return tile;
    }

    function latLonToPixel(lat, lon) {
        const n = Math.pow(2, zoom);

        lat = Math.max(-85.0511, Math.min(85.0511, lat));

        const x = ((lon + 180) / 360) * n;
        const latRad = lat * Math.PI / 180;
        const y = (1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * n;

        const centerX = ((centerLon + 180) / 360) * n;
        const centerLatRad = centerLat * Math.PI / 180;
        const centerY = (1 - Math.log(Math.tan(centerLatRad) + 1 / Math.cos(centerLatRad)) / Math.PI) / 2 * n;

        const pixelX = (x - centerX) * tileSize + mapWidth / 2;
        const pixelY = (y - centerY) * tileSize + mapHeight / 2;

        return { x: pixelX, y: pixelY };
    }

    canvas.addEventListener('mousedown', (e) => {
        isDragging = true;
        lastX = e.clientX;
        lastY = e.clientY;
        velocity = { x: 0, y: 0 };
    });

    canvas.addEventListener('mousemove', (e) => {
        if (!isDragging) return;

        const dx = e.clientX - lastX;
        const dy = e.clientY - lastY;

        const n = Math.pow(2, zoom);

        const dTileX = dx / tileSize;
        const dTileY = dy / tileSize;

        centerLon -= (dTileX / n) * 360;

        const centerLatRad = centerLat * Math.PI / 180;
        const centerTileY = (1 - Math.log(Math.tan(centerLatRad) + 1 / Math.cos(centerLatRad)) / Math.PI) / 2 * n;
        const newCenterTileY = centerTileY - dTileY;

        const minTileY = (mapHeight / 2) / tileSize;
        const maxTileY = n - (mapHeight / 2) / tileSize;
        const clampedTileY = Math.max(minTileY, Math.min(maxTileY, newCenterTileY));

        const newCenterY = (clampedTileY / n) * 2 - 1;
        centerLat = (Math.atan(Math.sinh(-newCenterY * Math.PI)) * 180) / Math.PI;

        centerLat = Math.max(-85.0511, Math.min(85.0511, centerLat));

        while (centerLon < -180) centerLon += 360;
        while (centerLon > 180) centerLon -= 360;

        velocity.x = dx;
        velocity.y = dy;

        lastX = e.clientX;
        lastY = e.clientY;
    });

    canvas.addEventListener('mouseup', () => {
        isDragging = false;
    });

    canvas.addEventListener('mouseleave', () => {
        isDragging = false;
    });

    function calculateTotalDistance(waypoints) {
        let total = 0;
        for (let i = 0; i < waypoints.length - 1; i++) {
            total += getDistance(waypoints[i], waypoints[i + 1]);
        }
        return total;
    }

    function getDistance(point1, point2) {
        const lat1 = point1.lat * Math.PI / 180;
        const lat2 = point2.lat * Math.PI / 180;
        const dLat = lat2 - lat1;
        const dLon = (point2.lon - point1.lon) * Math.PI / 180;

        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1) * Math.cos(lat2) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return 6371 * c;
    }

    function getCurrentPosition(waypoints, progress) {
        const totalDist = calculateTotalDistance(waypoints);
        const targetDist = totalDist * progress;

        let accumulatedDist = 0;
        for (let i = 0; i < waypoints.length - 1; i++) {
            const segmentDist = getDistance(waypoints[i], waypoints[i + 1]);
            if (accumulatedDist + segmentDist >= targetDist) {
                const segmentProgress = (targetDist - accumulatedDist) / segmentDist;
                return {
                    lat: waypoints[i].lat + (waypoints[i + 1].lat - waypoints[i].lat) * segmentProgress,
                    lon: waypoints[i].lon + (waypoints[i + 1].lon - waypoints[i].lon) * segmentProgress,
                    segmentIndex: i,
                    nextWaypoint: waypoints[i + 1].name
                };
            }
            accumulatedDist += segmentDist;
        }
        return {
            lat: waypoints[waypoints.length - 1].lat,
            lon: waypoints[waypoints.length - 1].lon,
            segmentIndex: waypoints.length - 1,
            nextWaypoint: 'Arrived'
        };
    }

    function roundRect(x, y, width, height, radius) {
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
    }

    function draw() {

        ctx.fillStyle = '#0a1929';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const n = Math.pow(2, zoom);

        const centerX = ((centerLon + 180) / 360) * n;
        const centerLatRad = centerLat * Math.PI / 180;
        const centerY = (1 - Math.log(Math.tan(centerLatRad) + 1 / Math.cos(centerLatRad)) / Math.PI) / 2 * n;

        const tilesWide = Math.ceil(mapWidth / tileSize) + 2;
        const tilesHigh = Math.ceil(mapHeight / tileSize) + 2;

        const centerTileX = Math.floor(centerX);
        const centerTileY = Math.floor(centerY);

        const offsetX = (centerX - centerTileX) * tileSize;
        const offsetY = (centerY - centerTileY) * tileSize;

        for (let ty = -Math.floor(tilesHigh / 2) - 1; ty <= Math.floor(tilesHigh / 2) + 1; ty++) {
            for (let tx = -Math.floor(tilesWide / 2) - 1; tx <= Math.floor(tilesWide / 2) + 1; tx++) {
                let tileX = centerTileX + tx;
                const tileY = centerTileY + ty;

                tileX = ((tileX % n) + n) % n;

                if (tileY < 0 || tileY >= n) continue;

                const tile = loadTile(tileX, tileY, zoom);

                if (tile.loaded) {
                    const pixelX = mapWidth / 2 + (tx * tileSize) - offsetX;
                    const pixelY = mapHeight / 2 + (ty * tileSize) - offsetY;

                    ctx.drawImage(tile.img, pixelX, pixelY, tileSize, tileSize);
                }
            }
        }

        if (data.route && data.route.waypoints) {
            const waypoints = data.route.waypoints;

            ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
            ctx.lineWidth = 8;
            ctx.shadowColor = '#3b82f6';
            ctx.shadowBlur = 20;

            ctx.beginPath();
            waypoints.forEach((waypoint, i) => {
                const pos = latLonToPixel(waypoint.lat, waypoint.lon);
                if (i === 0) {
                    ctx.moveTo(pos.x, pos.y);
                } else {
                    ctx.lineTo(pos.x, pos.y);
                }
            });
            ctx.stroke();

            ctx.strokeStyle = '#3b82f6';
            ctx.lineWidth = 4;
            ctx.shadowBlur = 0;
            ctx.setLineDash([10, 5]);

            ctx.beginPath();
            waypoints.forEach((waypoint, i) => {
                const pos = latLonToPixel(waypoint.lat, waypoint.lon);
                if (i === 0) {
                    ctx.moveTo(pos.x, pos.y);
                } else {
                    ctx.lineTo(pos.x, pos.y);
                }
            });
            ctx.stroke();
            ctx.setLineDash([]);

            waypoints.forEach((waypoint, i) => {
                const pos = latLonToPixel(waypoint.lat, waypoint.lon);

                if (i === 0 || i === waypoints.length - 1) {
                    ctx.fillStyle = i === 0 ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)';
                    ctx.shadowColor = i === 0 ? '#10b981' : '#ef4444';
                    ctx.shadowBlur = 20;
                    ctx.beginPath();
                    ctx.arc(pos.x, pos.y, 16, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.shadowBlur = 0;
                }

                ctx.fillStyle = i === 0 ? '#10b981' : (i === waypoints.length - 1 ? '#ef4444' : '#fbbf24');
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, 10, 0, Math.PI * 2);
                ctx.fill();

                ctx.fillStyle = '#fff';
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
                ctx.fill();

                ctx.font = 'bold 14px "Shadows Into Light", cursive, sans-serif';
                ctx.textAlign = 'center';
                const textWidth = ctx.measureText(waypoint.name).width;
                const padding = 8;

                roundRect(pos.x - textWidth/2 - padding, pos.y - 35, textWidth + padding * 2, 24, 6);
                ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
                ctx.fill();
                ctx.strokeStyle = i === 0 ? '#10b981' : (i === waypoints.length - 1 ? '#ef4444' : '#fbbf24');
                ctx.lineWidth = 2;
                ctx.stroke();

                ctx.fillStyle = '#fff';
                ctx.fillText(waypoint.name, pos.x, pos.y - 18);
            });

            if (data.assigned_to && data.assigned_to !== null) {
                currentProgress += animationSpeed;
                if (currentProgress > 1) currentProgress = 0;

                const currentPos = getCurrentPosition(waypoints, currentProgress);
                const pos = latLonToPixel(currentPos.lat, currentPos.lon);

                const gradient = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, 30);
                gradient.addColorStop(0, 'rgba(251, 191, 36, 0.6)');
                gradient.addColorStop(1, 'rgba(251, 191, 36, 0)');
                ctx.fillStyle = gradient;
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, 30, 0, Math.PI * 2);
                ctx.fill();

                ctx.font = '32px sans-serif';
                ctx.textAlign = 'center';
                ctx.shadowColor = '#000';
                ctx.shadowBlur = 5;
                ctx.fillText('🛷', pos.x, pos.y + 10);
                ctx.shadowBlur = 0;

                drawInfoPanel(currentPos, currentProgress);
            } else {
                drawInfoPanel({ nextWaypoint: 'Awaiting Assignment' }, 0);
            }
        }
    }

    function drawInfoPanel(currentPos, progress) {
        const panelWidth = 320;
        const panelHeight = 220;
        const padding = 20;
        const x = canvas.width - panelWidth - padding;
        const y = padding;

        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 30;
        roundRect(x, y, panelWidth, panelHeight, 16);
        ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.strokeStyle = 'rgba(59, 130, 246, 0.5)';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#3b82f6';
        ctx.font = 'bold 18px "Shadows Into Light", cursive, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText('🎁 DELIVERY STATUS', x + 20, y + 30);

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + 20, y + 40);
        ctx.lineTo(x + panelWidth - 20, y + 40);
        ctx.stroke();

        let currentY = y + 60;
        const lineHeight = 28;

        ctx.fillStyle = '#94a3b8';
        ctx.font = '14px "Shadows Into Light", cursive, sans-serif';
        ctx.fillText('Package:', x + 20, currentY);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 15px "Shadows Into Light", cursive, sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(data.package_id || data.recipient, x + panelWidth - 20, currentY);
        ctx.textAlign = 'left';

        currentY += lineHeight;

        ctx.fillStyle = '#94a3b8';
        ctx.font = '14px "Shadows Into Light", cursive, sans-serif';
        ctx.fillText('Next Stop:', x + 20, currentY);
        ctx.fillStyle = '#fbbf24';
        ctx.font = 'bold 15px "Shadows Into Light", cursive, sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(currentPos.nextWaypoint, x + panelWidth - 20, currentY);
        ctx.textAlign = 'left';

        currentY += lineHeight;

        ctx.fillStyle = '#94a3b8';
        ctx.font = '14px "Shadows Into Light", cursive, sans-serif';
        ctx.fillText('Progress:', x + 20, currentY);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 15px "Shadows Into Light", cursive, sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(`${Math.round(progress * 100)}%`, x + panelWidth - 20, currentY);
        ctx.textAlign = 'left';

        currentY += 8;

        const barWidth = panelWidth - 40;
        const barHeight = 8;
        roundRect(x + 20, currentY, barWidth, barHeight, 4);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.fill();

        roundRect(x + 20, currentY, barWidth * progress, barHeight, 4);
        const progressGradient = ctx.createLinearGradient(x + 20, 0, x + 20 + barWidth, 0);
        progressGradient.addColorStop(0, '#10b981');
        progressGradient.addColorStop(1, '#3b82f6');
        ctx.fillStyle = progressGradient;
        ctx.fill();

        currentY += 26;

        if (data.eta) {
            ctx.fillStyle = '#94a3b8';
            ctx.font = '14px "Shadows Into Light", cursive, sans-serif';
            ctx.fillText('ETA:', x + 20, currentY);
            ctx.fillStyle = '#4ade80';
            ctx.font = 'bold 15px "Shadows Into Light", cursive, sans-serif';
            ctx.textAlign = 'right';
            const eta = new Date(data.eta);
            ctx.fillText(eta.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}), x + panelWidth - 20, currentY);
            ctx.textAlign = 'left';

            currentY += lineHeight;
        }

        ctx.fillStyle = '#94a3b8';
        ctx.font = '14px "Shadows Into Light", cursive, sans-serif';
        ctx.fillText('Priority:', x + 20, currentY);

        const priorityColor = data.priority === 'high' ? '#ef4444' : '#fbbf24';
        roundRect(x + panelWidth - 85, currentY - 14, 65, 20, 6);
        ctx.fillStyle = priorityColor + '33';
        ctx.fill();
        ctx.strokeStyle = priorityColor;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.fillStyle = priorityColor;
        ctx.font = 'bold 13px "Shadows Into Light", cursive, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(data.priority.toUpperCase(), x + panelWidth - 52.5, currentY - 1);
    }

    function animate() {
        requestAnimationFrame(animate);

        if (!isDragging && (Math.abs(velocity.x) > 0.1 || Math.abs(velocity.y) > 0.1)) {
            const n = Math.pow(2, zoom);

            const dTileX = velocity.x / tileSize;
            const dTileY = velocity.y / tileSize;

            centerLon -= (dTileX / n) * 360;

            const centerLatRad = centerLat * Math.PI / 180;
            const centerTileY = (1 - Math.log(Math.tan(centerLatRad) + 1 / Math.cos(centerLatRad)) / Math.PI) / 2 * n;
            const newCenterTileY = centerTileY - dTileY;

            const minTileY = (mapHeight / 2) / tileSize;
            const maxTileY = n - (mapHeight / 2) / tileSize;
            const clampedTileY = Math.max(minTileY, Math.min(maxTileY, newCenterTileY));

            const newCenterY = (clampedTileY / n) * 2 - 1;
            centerLat = (Math.atan(Math.sinh(-newCenterY * Math.PI)) * 180) / Math.PI;

            centerLat = Math.max(-85.0511, Math.min(85.0511, centerLat));

            while (centerLon < -180) centerLon += 360;
            while (centerLon > 180) centerLon -= 360;

            velocity.x *= 0.95;
            velocity.y *= 0.95;

            if (Math.abs(velocity.x) < 0.1) velocity.x = 0;
            if (Math.abs(velocity.y) < 0.1) velocity.y = 0;
        }

        draw();
    }

    animate();
}
