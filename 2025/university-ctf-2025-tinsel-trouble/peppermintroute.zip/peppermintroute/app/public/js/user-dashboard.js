// User dashboard functionality

(async () => {
    const authResult = await Auth.checkAuth('user');
    if (!authResult) return;

    Auth.renderNavigation(authResult.user);

    try {
        const response = await fetch('/api/user/dashboard-data');
        const data = await response.json();

        document.getElementById('my-packages-count').textContent = data.myPackages || 0;
        document.getElementById('available-packages-count').textContent = data.availablePackages || 0;
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
})();
