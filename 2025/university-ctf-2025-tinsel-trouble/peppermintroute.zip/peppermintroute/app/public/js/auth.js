// Auth and Navigation utilities
class Auth {
    static async getCurrentUser() {
        try {
            const response = await fetch('/api/user');
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error fetching user:', error);
            return { authenticated: false, user: null };
        }
    }

    static async checkAuth(requiredRole = null) {
        const { authenticated, user } = await this.getCurrentUser();

        if (!authenticated) {
            window.location.href = '/login';
            return false;
        }

        if (requiredRole && user.role !== requiredRole) {
            window.location.href = '/';
            return false;
        }

        return { authenticated, user };
    }

    static renderNavigation(user = null) {
        const navbar = document.querySelector('.navbar');
        if (!navbar) return;

        const navMenu = navbar.querySelector('.nav-menu');
        if (!navMenu) return;

        if (user) {
            navMenu.innerHTML = `
                <li><a href="/${user.role}/dashboard/">Dashboard</a></li>
                ${user.role === 'user' ? '<li><a href="/user/packages">Packages</a></li>' : ''}
                ${user.role === 'admin' ? '<li><a href="/admin/recipient-management">Recipients</a></li>' : ''}
                ${user.role === 'admin' ? '<li><a href="/admin/pilots">Pilots</a></li>' : ''}
                <li><span class="user-badge">${escapeHtml(user.username)}</span></li>
                <li><a href="/logout" class="btn-logout">Logout</a></li>
            `;
        } else {
            navMenu.innerHTML = '<li><a href="/login" class="btn-login">Login</a></li>';
        }
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
