// 404 page functionality

(async () => {
    const { authenticated, user } = await Auth.getCurrentUser();
    if (authenticated && user) {
        Auth.renderNavigation(user);
    }
})();
