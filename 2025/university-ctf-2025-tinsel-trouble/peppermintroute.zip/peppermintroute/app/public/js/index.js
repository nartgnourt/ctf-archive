// Index page functionality

(async () => {
    const { authenticated, user } = await Auth.getCurrentUser();

    if (authenticated && user) {
        Auth.renderNavigation(user);
    }

    try {
        const response = await fetch('/api/public-stats');
        const data = await response.json();

        document.getElementById('pilots-count').textContent = data.pilots || 0;
        document.getElementById('packages-count').textContent = data.packages || 0;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
})();
