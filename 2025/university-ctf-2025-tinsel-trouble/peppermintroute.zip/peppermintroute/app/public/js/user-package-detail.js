// User package detail page functionality

function renderPackageDetail(data) {
    const { packageData, files, recipient } = data;

    let html = '<div class="quick-stats">';
    html += '<div class="stat-card-modern">';
    html += '<div class="stat-icon-modern">📮</div>';
    html += '<div class="stat-content-modern">';
    html += '<div class="stat-label-modern">Recipient</div>';
    html += `<div class="stat-value-modern">${escapeHtml(recipient)}</div>`;
    html += '</div></div>';

    html += '<div class="stat-card-modern">';
    html += '<div class="stat-icon-modern">⭐</div>';
    html += '<div class="stat-content-modern">';
    html += '<div class="stat-label-modern">Priority</div>';
    html += `<div class="stat-value-modern">${packageData.priority ? escapeHtml(packageData.priority.toUpperCase()) : 'N/A'}</div>`;
    html += '</div></div>';

    html += '<div class="stat-card-modern">';
    html += '<div class="stat-icon-modern">⏰</div>';
    html += '<div class="stat-content-modern">';
    html += '<div class="stat-label-modern">ETA</div>';
    html += `<div class="stat-value-modern">Dec 24, 2024 20:15</div>`;
    html += '</div></div>';
    html += '</div>';

    html += '<div class="map-container-main">';
    html += '<div class="map-header-bar">';
    html += '<h2>🌍 Live Tracking Map</h2>';
    html += '<div class="map-controls">';
    html += '<span class="live-indicator"><span class="pulse-dot"></span> LIVE</span>';
    html += '</div></div>';
    html += '<div class="map-wrapper">';
    html += '<canvas id="trackingMap"></canvas>';
    html += '</div></div>';

    html += '<div class="details-grid">';
    html += '<div class="card">';
    html += '<div class="card-header">📦 Package Details</div>';
    html += '<div class="card-body">';
    html += '<div class="info-row">';
    html += '<span class="info-label">Contents:</span>';
    html += `<span>${escapeHtml(packageData.contents || 'N/A')}</span>`;
    html += '</div>';
    html += '<div class="info-row">';
    html += '<span class="info-label">Notes:</span>';
    html += `<span>${escapeHtml(packageData.notes || 'N/A')}</span>`;
    html += '</div></div></div>';

    html += '<div class="card">';
    html += '<div class="card-header">📎 Supporting Files & Attachments</div>';
    html += '<div class="card-body">';

    if (files && files.length > 0) {
        html += '<div class="files-list">';
        files.forEach(file => {
            html += `<a href="/user/packages/${encodeURIComponent(recipient)}/download?fileId=${encodeURIComponent(file.file_id)}" class="file-item" download>`;
            html += `<div class="file-icon-small">${getFileIcon(file.filename)}</div>`;
            html += `<span class="file-name-text">${escapeHtml(file.filename)}</span>`;
            html += '<span class="download-icon">⬇️</span>';
            html += '</a>';
        });
        html += '</div>';
    } else {
        html += '<div class="empty-state-files">';
        html += '<div class="empty-icon">📭</div>';
        html += '<p>No files available for this package</p>';
        html += '</div>';
    }

    html += '</div></div></div>';

    document.getElementById('package-content').innerHTML = html;

    packageData.destination = {
        name: packageData.dest_name || '',
        coordinates: {
            lat: Number(packageData.dest_lat) || 0,
            lon: Number(packageData.dest_lon) || 0
        },
        timezone: 'UTC'
    };

    packageData.route = {
        distance_km: 4200,
        estimated_time_hours: 7.2
    };

    packageData.weather = {
        current: {
            temp_celsius: -15,
            condition: 'Snowy',
            visibility_km: 5.0,
            wind_speed_kmh: 30
        },
        forecast: 'Light snow with moderate winds. Good visibility expected.'
    };

    packageData.package_id = packageData.recipient;

    window.packageData = packageData;

    if (typeof initializeMap === 'function') {
        setTimeout(() => initializeMap(packageData), 100);
    } else {
        const script = document.createElement('script');
        script.src = '/js/admin-package-map.js';
        script.onload = () => {
            setTimeout(() => initializeMap(packageData), 100);
        };
        document.body.appendChild(script);
    }
}

(async () => {
    const pathParts = window.location.pathname.split('/');
    const recipient = decodeURIComponent(pathParts[pathParts.length - 1]);

    const authResult = await Auth.checkAuth('user');
    if (!authResult) return;

    Auth.renderNavigation(authResult.user);
    document.getElementById('username').textContent = `👤 ${authResult.user.username}`;

    try {
        const response = await fetch(`/api/user/package/${encodeURIComponent(recipient)}`);
        if (!response.ok) {
            if (response.status === 404) {
                document.getElementById('package-content').innerHTML = '<p class="no-data">Package not found</p>';
            } else if (response.status === 403) {
                document.getElementById('package-content').innerHTML = '<p class="no-data">Access denied: This package is not assigned to you</p>';
            } else {
                throw new Error('Failed to load package');
            }
            return;
        }

        const data = await response.json();
        renderPackageDetail(data);
    } catch (error) {
        console.error('Error loading package:', error);
        document.getElementById('package-content').innerHTML = '<p class="no-data">Error loading package</p>';
    }
})();
