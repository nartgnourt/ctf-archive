// Admin package detail page functionality

(async () => {
    const authResult = await Auth.checkAuth('admin');
    if (!authResult) return;
    Auth.renderNavigation(authResult.user);

    const pathParts = window.location.pathname.split('/');
    const recipient = decodeURIComponent(pathParts[pathParts.length - 1]);

    try {
        const response = await fetch(`/api/admin/package/${encodeURIComponent(recipient)}`);
        if (!response.ok) {
            document.getElementById('main-content').innerHTML = '<p class="empty-state">Error loading package</p>';
            return;
        }
        const data = await response.json();

        document.getElementById('page-title').textContent = `Packages for ${data.recipient}`;
        document.getElementById('page-subtitle').textContent = `${data.packages.length} package(s)`;

        if (data.warning) {
            document.getElementById('warning-container').innerHTML = `<div class="alert-warning"><strong>⚠️ Warning:</strong> ${escapeHtml(data.warning)}</div>`;
        }

        if (data.packages.length > 0) {
            document.getElementById('map-container').innerHTML = `
                <div class="map-container-main">
                    <div class="map-header-bar">
                        <h2>🌍 Route Tracking Map</h2>
                        <div class="map-controls">
                            <span class="live-indicator"><span class="pulse-dot"></span> LIVE</span>
                        </div>
                    </div>
                    <div class="map-wrapper">
                        <canvas id="trackingMap"></canvas>
                    </div>
                </div>
            `;
        }

        let html = '<div class="admin-section"><h3>Package Information</h3><div class="routes-table-container"><table class="data-table"><thead><tr><th>Destination</th><th>Priority</th><th>Status</th><th>Assigned To</th></tr></thead><tbody>';

        if (data.packages.length === 0) {
            html += '<tr><td colspan="4" class="empty-state">No package details imported yet. Create package details using the form below.</td></tr>';
        } else {
            data.packages.forEach(pkg => {
                const destData = { name: pkg.dest_name || 'N/A' };

                html += `<tr>`;
                html += `<td>${escapeHtml(destData.name)}</td>`;
                html += `<td><span class="badge badge-${pkg.priority}">${escapeHtml(pkg.priority.toUpperCase())}</span></td>`;

                if (pkg.status === 'delivered') {
                    html += '<td><span class="badge badge-delivered">Delivered</span></td>';
                } else if (pkg.status === 'in_transit') {
                    html += '<td><span class="badge badge-in-transit">In Transit</span></td>';
                } else {
                    html += '<td><span class="badge badge-pending">Pending</span></td>';
                }

                html += `<td>${escapeHtml(pkg.assigned_to || 'Unassigned')}</td>`;
                html += `</tr>`;
            });
        }
        html += '</tbody></table></div></div>';

        if (data.packages.length === 0) {
            html += `<div class="admin-section" style="margin-bottom: 20px;"><div class="section-header"><h3>Create Package Details</h3></div>
            <form action="/admin/recipients/${encodeURIComponent(recipient)}/create-package" method="POST" class="admin-form">
                <div class="form-group"><label for="destination_name">Destination Name</label><input type="text" id="destination_name" name="destination_name" required class="form-control" placeholder="e.g., London, United Kingdom"></div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group"><label for="destination_lat">Latitude</label><input type="number" step="any" id="destination_lat" name="destination_lat" required class="form-control" placeholder="e.g., 51.5074" min="-90" max="90"><small class="form-text">Must be between -90 and 90</small></div>
                    <div class="form-group"><label for="destination_lon">Longitude</label><input type="number" step="any" id="destination_lon" name="destination_lon" required class="form-control" placeholder="e.g., -0.1278" min="-180" max="180"><small class="form-text">Must be between -180 and 180</small></div>
                </div>
                <div class="form-group"><label for="priority">Priority</label><select id="priority" name="priority" required class="form-control"><option value="low">Low</option><option value="medium" selected>Medium</option><option value="high">High</option></select></div>
                <div class="form-group"><label for="contents">Package Contents</label><input type="text" id="contents" name="contents" class="form-control" placeholder="e.g., Standard winter package"></div>
                <div class="form-group"><label for="notes">Delivery Notes</label><textarea id="notes" name="notes" class="form-control" rows="3" placeholder="Special delivery instructions..."></textarea></div>
                <button type="submit" class="btn btn-primary btn-block">Create Package</button>
            </form></div>`;
        }

        const currentlyAssigned = data.packages.length > 0 ? data.packages[0].assigned_to : null;
        let pilotsOptions = '<option value="">-- Select a pilot --</option>';
        data.pilots.forEach(pilot => {
            pilotsOptions += `<option value="${escapeHtml(pilot.username)}" ${currentlyAssigned === pilot.username ? 'selected' : ''}>${escapeHtml(pilot.username)}</option>`;
        });

        html += `<div class="admin-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
            <div class="admin-section"><div class="section-header"><h3>Upload Attachments</h3></div>
            <form action="/admin/recipients/${encodeURIComponent(recipient)}/upload" method="POST" enctype="multipart/form-data" class="admin-form">
                <div class="form-group"><label for="files">Select Files</label><input type="file" id="files" name="files" multiple required class="form-control"><small class="form-text">Upload any supporting documents for the pilot. Zip files will be extracted automatically.</small></div>
                <button type="submit" class="btn btn-primary btn-block">Upload Attachments</button>
            </form></div>
            <div class="admin-section"><div class="section-header"><h3>Assign Pilot</h3></div>
            <form action="/admin/recipients/${encodeURIComponent(recipient)}/assign" method="POST" class="admin-form">
                <div class="form-group"><label for="username">Select Pilot</label><select id="username" name="username" required class="form-control">${pilotsOptions}</select>
                <small class="form-text">${currentlyAssigned ? `Currently assigned to: <strong>${escapeHtml(currentlyAssigned)}</strong>` : 'Assign a pilot to deliver this package'}</small></div>
                <button type="submit" class="btn btn-primary btn-block">${currentlyAssigned ? 'Reassign Package' : 'Assign Package'}</button>
            </form></div>
        </div>`;

        html += `<div class="admin-section files-section" style="width: 100%;"><div class="section-header"><h3>Supporting Files</h3><span class="badge">${data.files.length} files</span></div>`;
        if (data.files.length === 0) {
            html += '<p class="empty-state">No supporting files uploaded</p>';
        } else {
            html += '<div class="files-grid">';
            data.files.forEach(file => {
                html += `<div class="file-card"><div class="file-icon">${getFileIcon(file.filename)}</div>
                <div class="file-name">${escapeHtml(file.filename)}</div>
                <div class="file-meta"><small>ID: ${escapeHtml(file.file_id.substring(0, 8))}...</small></div></div>`;
            });
            html += '</div>';
        }
        html += '</div>';

        document.getElementById('main-content').innerHTML = html;

        if (data.packages.length > 0) {
            const pkg = data.packages[0];

            console.log(`[ADMIN MAP] Package destination from DB: lat=${pkg.dest_lat}, lon=${pkg.dest_lon}`);
            pkg.destination = {
                name: pkg.dest_name || '',
                coordinates: {
                    lat: Number(pkg.dest_lat) || 0,
                    lon: Number(pkg.dest_lon) || 0
                },
                timezone: 'UTC'
            };
            console.log(`[ADMIN MAP] Set destination coordinates: lat=${pkg.destination.coordinates.lat}, lon=${pkg.destination.coordinates.lon}`);

            pkg.route = {
                distance_km: 4200,
                estimated_time_hours: 7.2
            };

            pkg.weather = {
                current: {
                    temp_celsius: -15,
                    condition: 'Snowy',
                    visibility_km: 5.0,
                    wind_speed_kmh: 30
                },
                forecast: 'Light snow with moderate winds. Good visibility expected.'
            };

            pkg.package_id = pkg.recipient;

            window.packageData = pkg;

            if (typeof initializeMap === 'function') {
                setTimeout(() => initializeMap(pkg), 100);
            } else {
                const script = document.createElement('script');
                script.src = '/js/admin-package-map.js';
                script.onload = () => {
                    setTimeout(() => initializeMap(pkg), 100);
                };
                document.body.appendChild(script);
            }
        }
    } catch (error) {
        console.error('Error loading package details:', error);
        document.getElementById('main-content').innerHTML = '<p class="empty-state">Error loading package details</p>';
    }
})();
