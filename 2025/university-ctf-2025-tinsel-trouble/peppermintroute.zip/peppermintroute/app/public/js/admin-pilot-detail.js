// Admin pilot detail page functionality

(async () => {
    const authResult = await Auth.checkAuth('admin');
    if (!authResult) return;
    Auth.renderNavigation(authResult.user);

    const pathParts = window.location.pathname.split('/');
    const username = decodeURIComponent(pathParts[pathParts.length - 1]);

    try {
        const response = await fetch(`/api/admin/pilot/${encodeURIComponent(username)}`);
        if (!response.ok) {
            throw new Error('Failed to load pilot data');
        }
        const data = await response.json();

        document.getElementById('pilot-title').textContent = `Pilot: ${data.pilotUsername}`;
        document.getElementById('package-count').textContent = `${data.packages.length} assigned package(s)`;

        const tbody = document.getElementById('packages-tbody');
        if (data.packages.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No packages assigned to this pilot yet</td></tr>';
        } else {
            let html = '';
            data.packages.forEach(pkg => {
                const destData = { name: pkg.dest_name || 'N/A' };

                html += `<tr>`;
                html += `<td><strong>${escapeHtml(pkg.recipient)}</strong></td>`;
                html += `<td>${escapeHtml(destData.name)}</td>`;
                html += `<td><span class="badge badge-${pkg.priority}">${escapeHtml(pkg.priority.toUpperCase())}</span></td>`;

                let statusBadge = '';
                if (pkg.status === 'delivered') {
                    statusBadge = '<span class="badge badge-delivered">Delivered</span>';
                } else if (pkg.status === 'in_transit') {
                    statusBadge = '<span class="badge badge-in-transit">In Transit</span>';
                } else {
                    statusBadge = '<span class="badge badge-pending">Pending</span>';
                }
                html += `<td>${statusBadge}</td>`;
                html += `<td><a href="/admin/recipients/${encodeURIComponent(pkg.recipient)}" class="action-btn">View Package</a></td>`;
                html += `</tr>`;
            });
            tbody.innerHTML = html;
        }
    } catch (error) {
        console.error('Error loading pilot details:', error);
        document.getElementById('packages-tbody').innerHTML = '<tr><td colspan="5" class="empty-state">Error loading pilot details</td></tr>';
    }
})();
