// Utility functions shared across pages

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function calculateDistance(sourceLat, sourceLon, destLat, destLon) {
    const distance = Math.sqrt(
        Math.pow(destLat - sourceLat, 2) +
        Math.pow(destLon - sourceLon, 2)
    ) * 111;
    return distance.toFixed(0);
}

function getFileIcon(filename) {
    if (filename.endsWith('.png') || filename.endsWith('.jpg') || filename.endsWith('.jpeg')) {
        return '🖼️';
    } else if (filename.endsWith('.pdf')) {
        return '📄';
    } else if (filename.endsWith('.txt')) {
        return '📝';
    } else {
        return '📦';
    }
}
