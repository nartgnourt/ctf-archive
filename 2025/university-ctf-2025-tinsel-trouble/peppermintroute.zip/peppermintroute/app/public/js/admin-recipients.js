// Admin recipients page functionality

(async () => {
    const authResult = await Auth.checkAuth('admin');
    if (!authResult) return;
    Auth.renderNavigation(authResult.user);

    try {
        const response = await fetch('/api/admin/recipients-data');
        const data = await response.json();
        const tbody = document.getElementById('recipients-tbody');
        const countBadge = document.getElementById('recipient-count');

        countBadge.textContent = `${data.recipients.length} recipients`;

        if (data.recipients.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="empty-state">No recipients created yet</td></tr>';
        } else {
            let html = '';
            data.recipients.forEach(recipient => {
                const createdAt = new Date(recipient.created_at).toLocaleString();
                html += `<tr>`;
                html += `<td><strong>${escapeHtml(recipient.recipient_name)}</strong></td>`;
                html += `<td>${escapeHtml(createdAt)}</td>`;
                html += `<td><a href="/admin/recipients/${encodeURIComponent(recipient.recipient_name)}" class="action-btn">View Details</a></td>`;
                html += `</tr>`;
            });
            tbody.innerHTML = html;
        }
    } catch (error) {
        console.error('Error loading recipients:', error);
        document.getElementById('recipients-tbody').innerHTML = '<tr><td colspan="3" class="empty-state">Error loading recipients</td></tr>';
    }
})();
