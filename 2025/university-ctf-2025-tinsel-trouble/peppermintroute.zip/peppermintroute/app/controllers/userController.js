const { query } = require('../models/mysqldb');
const path = require('path');

exports.getDashboard = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/user/dashboard.html'));
};


exports.getPackages = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/user/packages.html'));
};

exports.pickupPackage = async (req, res) => {
    try {
        const { recipient } = req.body;

        await query(
            'UPDATE packages SET assigned_to = ?, status = ? WHERE recipient = ?',
            [req.session.username, 'in_transit', recipient]
        );

        res.redirect('/user/packages');
    } catch (error) {
        console.error('Pickup error:', error);
        res.status(400).send('Error picking up package: ' + error.message);
    }
};
