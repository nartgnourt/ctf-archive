const { query } = require('../models/mysqldb');
const Package = require('../models/Package');
const path = require('path');
const fs = require('fs');

exports.downloadAttachment = async (req, res) => {
    try {
        const { fileId } = req.query;

        if (!fileId) {
            return res.status(400).json({ error: 'fileId is required' });
        }

        const fileRecord = await Package.getFileById(fileId);

        if (!fileRecord) {
            return res.status(404).json({ error: 'File not found' });
        }

        const packageResults = await query(
            'SELECT assigned_to FROM packages WHERE recipient = ?',
            [fileRecord.recipient]
        );

        if (!packageResults || packageResults.length === 0) {
            return res.status(404).json({ error: 'Package not found' });
        }

        if (packageResults[0].assigned_to !== req.session.username) {
            return res.status(403).json({ error: 'Access denied: This file is not assigned to you' });
        }

        const filePath = fileRecord.filepath;
        const resolvedFilePath = path.resolve(filePath);
        const uploadsDir = path.resolve('/app/data/uploads');

        if (!resolvedFilePath.startsWith(uploadsDir + path.sep)) {
            return res.status(403).json({ error: 'Access denied: Invalid file location' });
        }

        res.setHeader('Content-Disposition', `attachment; filename="${fileRecord.filename}"`);
        res.setHeader('Content-Type', 'application/octet-stream');

        const fileStream = fs.createReadStream(filePath);
        fileStream.pipe(res);
    } catch (error) {
        console.error('Download error:', error);
        res.status(500).json({ error: 'Error downloading file' });
    }
};

exports.viewPackage = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/user/package-detail.html'));
};
