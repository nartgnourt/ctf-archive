const User = require('../models/User');
const Package = require('../models/Package');
const Recipient = require('../models/Recipient');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ZipParser = require('../utils/zipParser');
const { query } = require('../models/mysqldb');

exports.getDashboard = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin/dashboard.html'));
};

exports.getPilots = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin/pilots.html'));
};

exports.getPilotDetail = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin/pilot-detail.html'));
};

exports.uploadFiles = async (req, res) => {
    try {
        const { recipient } = req.params;

        if (!req.files || req.files.length === 0) {
            return res.status(400).send('No files uploaded');
        }

        const recipientExists = await Recipient.exists(recipient);
        if (!recipientExists) {
            return res.status(404).send('Recipient not found. Please create the recipient first.');
        }

        for (const file of req.files) {
            if (file.originalname.endsWith('.zip')) {
                try {
                    const zipPath = file.path;
                    const extractDir = path.dirname(zipPath);

                    const parser = new ZipParser(zipPath);
                    const extractedFiles = parser.extractAll(extractDir);


                    for (const filePath of extractedFiles) {
                        const fileName = path.basename(filePath);
                        const fileId = crypto.randomBytes(16).toString('hex');

                        await query(
                            `REPLACE INTO file_attachments (file_id, recipient, filename, filepath)
                                VALUES (?, ?, ?, ?)`,
                            [fileId, recipient, fileName, filePath]
                        );

                    }

                    fs.unlinkSync(zipPath);
                } catch (error) {
                    console.error(`Error extracting ZIP ${file.originalname}:`, error);
                }
            } else {
                await query(
                    `REPLACE INTO file_attachments (file_id, recipient, filename, filepath)
                     VALUES (?, ?, ?, ?)`,
                    [file.fileId, recipient, file.filename, file.path]
                );

            }
        }

        res.redirect(`/admin/recipients/${recipient}`);
    } catch (error) {
        console.error('Upload files error:', error);
        res.status(500).send('Error uploading files: ' + error.message);
    }
};

exports.assignPackage = async (req, res) => {
    const { recipient } = req.params;
    const { username } = req.body;

    try {
        if (!username) {
            return res.status(400).send('Missing required field: username');
        }

        await Package.assignToUser(recipient, username);
        res.redirect(`/admin/recipients/${recipient}`);
    } catch (error) {
        console.error(`Error assigning package for recipient ${recipient}:`, error);
        res.status(400).send('Error assigning package: ' + error.message);
    }
};

exports.getPackageDetail = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin/package-detail.html'));
};


exports.getRecipientManagement = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin/recipient-management.html'));
};

exports.createRecipient = async (req, res) => {
    try {
        const { recipientName } = req.body;

        if (!recipientName || typeof recipientName !== 'string') {
            return res.status(400).send('Recipient name is required');
        }

        if (!/^[a-zA-Z0-9_-]+$/.test(recipientName)) {
            return res.status(400).send('Recipient name can only contain letters, numbers, underscores, and hyphens');
        }

        const exists = await Recipient.exists(recipientName);
        if (exists) {
            return res.status(400).send('Recipient already exists');
        }

        await Recipient.create(recipientName);
        console.log(`Created recipient: ${recipientName}`);
        res.redirect('/admin/recipient-management');
    } catch (error) {
        console.error('Create recipient error:', error);
        res.status(500).send('Error creating recipient: ' + error.message);
    }
};

exports.createPackageFromForm = async (req, res) => {
    try {
        const { recipient } = req.params;
        const { destination_name, destination_lat, destination_lon, priority, contents, notes } = req.body;

        const recipientExists = await Recipient.exists(recipient);
        if (!recipientExists) {
            return res.status(404).send('Recipient not found');
        }

        if (!destination_name || !destination_lat || !destination_lon || !priority) {
            return res.status(400).send('Missing required fields');
        }

        const lat = parseFloat(destination_lat);
        const lon = parseFloat(destination_lon);

        if (isNaN(lat) || isNaN(lon)) {
            return res.status(400).send('Invalid latitude or longitude');
        }

        if (lat < -90 || lat > 90) {
            return res.status(400).send('Latitude must be between -90 and 90');
        }

        if (lon < -180 || lon > 180) {
            return res.status(400).send('Longitude must be between -180 and 180');
        }

        if (!['low', 'medium', 'high'].includes(priority)) {
            return res.status(400).send('Invalid priority value');
        }

        await Package.create(
            recipient,
            destination_name,
            lat,
            lon,
            priority,
            contents || '',
            notes || '',
            null,
            'pending'
        );

        console.log(`Created package for recipient: ${recipient}`);
        res.redirect(`/admin/recipients/${recipient}`);
    } catch (error) {
        console.error('Create package error:', error);
        res.status(500).send('Error creating package: ' + error.message);
    }
};