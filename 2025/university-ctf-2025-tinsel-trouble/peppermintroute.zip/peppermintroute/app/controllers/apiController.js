const { query } = require('../models/mysqldb');
const Package = require('../models/Package');
const Recipient = require('../models/Recipient');
const User = require('../models/User');

exports.getCurrentUser = (req, res) => {
    if (req.session.userId) {
        res.json({
            authenticated: true,
            user: {
                username: req.session.username,
                role: req.session.role
            }
        });
    } else {
        res.json({
            authenticated: false,
            user: null
        });
    }
};

exports.getPublicStats = async (req, res) => {
    try {
        const pilotCountResult = await query('SELECT COUNT(*) as count FROM users WHERE role = ?', ['user']);
        const packageCountResult = await query('SELECT COUNT(*) as count FROM packages', []);

        res.json({
            pilots: pilotCountResult[0].count,
            packages: packageCountResult[0].count
        });
    } catch (error) {
        console.error('Public stats error:', error);
        res.status(500).json({ error: 'Error loading stats' });
    }
};

exports.getUserDashboardData = async (req, res) => {
    try {
        const myPackagesResult = await query('SELECT COUNT(*) as count FROM packages WHERE assigned_to = ?', [req.session.username]);
        const availablePackagesResult = await query('SELECT COUNT(*) as count FROM packages WHERE assigned_to IS NULL OR status = ?', ['pending']);

        res.json({
            myPackages: myPackagesResult[0].count,
            availablePackages: availablePackagesResult[0].count
        });
    } catch (error) {
        console.error('User dashboard data error:', error);
        res.status(500).json({ error: 'Error loading dashboard data' });
    }
};

exports.getUserPackagesData = async (req, res) => {
    try {
        const myPackagesRaw = await query('SELECT * FROM packages WHERE assigned_to = ?', [req.session.username]);
        const availablePackagesRaw = await query('SELECT * FROM packages WHERE assigned_to IS NULL OR status = ?', ['pending']);

        const SOURCE_LAT = 59.9139;
        const SOURCE_LON = 10.7522;

        const parsePackage = (pkg) => {
            console.log(`[SERVER] Returning location for ${pkg.recipient}: lat=${pkg.dest_lat}, lon=${pkg.dest_lon}`);
            return {
                recipient: pkg.recipient,
                status: pkg.status,
                source_lat: SOURCE_LAT,
                source_lon: SOURCE_LON,
                dest_lat: Number(pkg.dest_lat) || 0,
                dest_lon: Number(pkg.dest_lon) || 0,
                dest_city: pkg.dest_name ? pkg.dest_name.split(',')[0] : '',
                dest_country: pkg.dest_name ? pkg.dest_name.split(',').slice(1).join(',').trim() : ''
            };
        };

        const myPackages = myPackagesRaw.map(parsePackage);
        const availablePackages = availablePackagesRaw.map(parsePackage);

        res.json({
            myPackages: myPackages,
            availablePackages: availablePackages
        });
    } catch (error) {
        console.error('User packages data error:', error);
        res.status(500).json({ error: 'Error loading packages data' });
    }
};

exports.getPackageDetailData = async (req, res) => {
    try {
        const { recipient } = req.params;

        const results = await query(
            'SELECT * FROM packages WHERE recipient = ?',
            [recipient]
        );

        if (!results || results.length === 0) {
            return res.status(404).json({ error: 'Package not found' });
        }

        const packageData = results[0];

        if (packageData.assigned_to !== req.session.username) {
            return res.status(403).json({ error: 'Access denied: This package is not assigned to you' });
        }

        const allFiles = await Package.getFiles(recipient);

        res.json({
            packageData: packageData,
            files: allFiles,
            recipient: recipient
        });
    } catch (error) {
        console.error('Package detail data error:', error);
        res.status(500).json({ error: 'Error loading package detail' });
    }
};

exports.getAdminDashboardData = async (req, res) => {
    try {
        const pilotCountResult = await query('SELECT COUNT(*) as count FROM users WHERE role = ?', ['user']);
        const packageCountResult = await query('SELECT COUNT(*) as count FROM packages', []);

        res.json({
            totalPilots: pilotCountResult[0].count,
            totalPackages: packageCountResult[0].count
        });
    } catch (error) {
        console.error('Admin dashboard data error:', error);
        res.status(500).json({ error: 'Error loading dashboard data' });
    }
};

exports.getRecipientsData = async (req, res) => {
    try {
        const recipients = await Recipient.getAll();
        res.json({ recipients });
    } catch (error) {
        console.error('Recipients data error:', error);
        res.status(500).json({ error: 'Error loading recipients' });
    }
};

exports.getPilotsData = async (req, res) => {
    try {

        const pilots = await User.getAllPilots();
        res.json({ pilots });
    } catch (error) {
        console.error('Pilots data error:', error);
        res.status(500).json({ error: 'Error loading pilots' });
    }
};

exports.getPilotDetailData = async (req, res) => {
    try {
        const { username } = req.params;


        const pilot = await User.findByUsername(username);
        if (!pilot || pilot.role !== 'user') {
            return res.status(404).json({ error: 'Pilot not found' });
        }

        const packages = await Package.findByAssignedUser(username);
        res.json({ pilotUsername: username, packages });
    } catch (error) {
        console.error('Pilot detail data error:', error);
        res.status(500).json({ error: 'Error loading pilot detail' });
    }
};

exports.getAdminPackageDetailData = async (req, res) => {
    try {
        const { recipient } = req.params;

        const recipientExists = await Recipient.exists(recipient);
        if (!recipientExists) {
            return res.status(404).json({ error: 'Recipient not found' });
        }

        const packages = await Package.findByRecipient(recipient);
        const allFiles = await Package.getFiles(recipient);
        const pilots = await User.getAllPilots();
        const files = allFiles.filter(file => file.filename !== `${recipient}.json`);

        let warning = null;
        if (packages.length === 0) {
            warning = `No package details found,`;
        }

        res.json({ recipient, packages, files, pilots, warning });
    } catch (error) {
        console.error('Admin package detail data error:', error);
        res.status(500).json({ error: 'Error loading package detail' });
    }
};
