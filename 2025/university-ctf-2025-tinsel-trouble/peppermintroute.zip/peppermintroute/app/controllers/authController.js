const path = require('path');
const { query } = require('../models/mysqldb');

exports.getLogin = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/login.html'));
};

exports.postLogin = async (req, res) => {
    const { username, password } = req.body;

    if (username && password) {
        try {
            const results = await query(
                'SELECT * FROM users WHERE username = ? AND password = ?',
                [username, password]
            );

            if (results.length > 0) {
                const user = results[0];

                req.session.userId = user.id;
                req.session.username = user.username;
                req.session.role = user.role;

                if (user.role === 'admin') {
                    return res.redirect('/admin/dashboard');
                } else {
                    return res.redirect('/user/dashboard');
                }
            } else {
                return res.status(401).json({
                    error: 'Incorrect Username and/or Password!'
                });
            }
        } catch (error) {
            console.error('Login error:', error);
            return res.status(500).json({
                error: 'Login failed. Please try again.'
            });
        }
    } else {
        return res.status(400).json({
            error: 'Please enter Username and Password!'
        });
    }
};


exports.logout = (req, res) => {
    req.session.destroy();
    res.redirect('/');
};

exports.requireAuth = (req, res, next) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    next();
};

exports.requireAdmin = (req, res, next) => {
    if (!req.session.userId || req.session.role !== 'admin') {
        return res.status(403).send('Access denied');
    }
    next();
};

exports.requireUser = (req, res, next) => {
    if (!req.session.userId || req.session.role !== 'user') {
        return res.status(403).send('Access denied');
    }
    next();
};
