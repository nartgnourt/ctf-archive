const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForMySQL(maxRetries = 10, retryDelay = 2000) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            const connection = await mysql.createConnection({
                host: process.env.DB_HOST || '127.0.0.1',
                user: process.env.DB_USER || 'root',
                password: process.env.DB_PASSWORD || ''
            });
            await connection.end();
            console.log('[MySQL] Connection successful');
            return true;
        } catch (error) {
            console.log(`[MySQL] Connection attempt ${i + 1}/${maxRetries} failed: ${error.message}`);
            console.log(`[MySQL] Error code: ${error.code}, errno: ${error.errno}`);
            console.log(`[MySQL] Retrying in ${retryDelay}ms...`);
            await sleep(retryDelay);
        }
    }
    throw new Error('Failed to connect to MySQL after maximum retries');
}

async function initializeDatabase() {
    let connection;

    try {

        await waitForMySQL();

        connection = await mysql.createConnection({
            host: process.env.DB_HOST || '127.0.0.1',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || ''
        });

        console.log('[MySQL] Connecting to database...');

        await connection.query('CREATE DATABASE IF NOT EXISTS peppermintroute');
        await connection.query('USE peppermintroute');

        // Check if packages table exists and has old schema
        const [tables] = await connection.query("SHOW TABLES LIKE 'packages'");
        if (tables.length > 0) {
            // Table exists, check if it has old columns
            const [columns] = await connection.query("SHOW COLUMNS FROM packages LIKE 'dest_timezone'");
            if (columns.length > 0) {
                // Old schema detected, drop and recreate
                console.log('[MySQL] Detected old schema, recreating packages table...');
                await connection.query('DROP TABLE IF EXISTS packages');
            }
        }

        await connection.query(`
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                role ENUM('user', 'admin') DEFAULT 'user',
                destination VARCHAR(255),
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_username (username)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);

        await connection.query(`
            CREATE TABLE IF NOT EXISTS recipients (
                id INT AUTO_INCREMENT PRIMARY KEY,
                recipient_name VARCHAR(255) NOT NULL UNIQUE,
                directory_id VARCHAR(64) NOT NULL UNIQUE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_recipient_name (recipient_name),
                INDEX idx_directory_id (directory_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);

        await connection.query(`
            CREATE TABLE IF NOT EXISTS packages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                recipient VARCHAR(255) NOT NULL UNIQUE,
                dest_name VARCHAR(255),
                dest_lat DECIMAL(10, 8),
                dest_lon DECIMAL(11, 8),
                priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
                contents TEXT,
                notes TEXT,
                assigned_to VARCHAR(255),
                status ENUM('pending', 'in_transit', 'delivered') DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_recipient (recipient),
                INDEX idx_assigned_to (assigned_to),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);

        await connection.query(`
            CREATE TABLE IF NOT EXISTS file_attachments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                file_id VARCHAR(32) NOT NULL UNIQUE,
                recipient VARCHAR(255) NOT NULL,
                filename VARCHAR(255) NOT NULL,
                filepath VARCHAR(500) NOT NULL,
                uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_recipient (recipient),
                INDEX idx_file_id (file_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);

        console.log('[MySQL] Tables created successfully');

        await connection.query('DELETE FROM users');
        console.log('[MySQL] Cleared existing users');

        const adminUsername = `admin_${crypto.randomBytes(16).toString('hex')}`;
        const adminPassword = crypto.randomBytes(16).toString('hex');

        await connection.query(`
            INSERT INTO users (username, password, role, destination)
            VALUES (?, ?, ?, ?)
        `, [adminUsername, adminPassword, 'admin', 'Tinselwick Village']);

        console.log('\n========================================');
        console.log('ADMIN CREDENTIALS');
        console.log('========================================');
        console.log(`Username: ${adminUsername}`);
        console.log(`Password: ${adminPassword}`);
        console.log('========================================\n');
        const pilotDestinations = [
            'Northern Lights Station',
            'Glacier Peak',
            'Crystal Caverns',
            'Evergreen Forest',
            'Frost Valley',
            'Glacier Bay',
            'Holly Hills',
            'Icicle Ridge',
            'Jinglebell Junction'
        ];

        const pilotBaseNames = [
            'pilot_aurora',
            'pilot_blizzard',
            'pilot_crystal',
            'pilot_evergreen',
            'pilot_frost',
            'pilot_glacier',
            'pilot_holly',
            'pilot_icicle',
            'pilot_jingle'
        ];

        console.log('\n========================================');
        console.log('PILOT CREDENTIALS');
        console.log('========================================');

        for (let i = 0; i < pilotBaseNames.length; i++) {
            const randomPrefix = crypto.randomBytes(16).toString('hex');
            const username = `${pilotBaseNames[i]}_${randomPrefix}`;
            const password = crypto.randomBytes(16).toString('hex');
            const destination = pilotDestinations[i];

            await connection.query(`
                INSERT INTO users (username, password, role, destination)
                VALUES (?, ?, ?, ?)
            `, [username, password, 'user', destination]);

            console.log(`${username} / ${password} (${destination})`);
        }

        console.log('========================================\n');
        console.log('[MySQL] Created 9 pilots with random credentials');

        const packagesDir = path.join(__dirname, 'data/packages');

        if (fs.existsSync(packagesDir)) {
            const files = fs.readdirSync(packagesDir).filter(file => file.endsWith('.json'));

            if (files.length > 0) {
                console.log(`[MySQL] Found ${files.length} package files to import`);

                for (const file of files) {
                    try {
                        const filePath = path.join(packagesDir, file);
                        const fileContent = fs.readFileSync(filePath, 'utf8');
                        const packageData = JSON.parse(fileContent);

                        // Validate package data structure
                        if (!packageData || typeof packageData !== 'object') {
                            console.error(`[MySQL] Invalid package data in ${file}, skipping`);
                            continue;
                        }

                        if (!packageData.recipient || typeof packageData.recipient !== 'string') {
                            console.error(`[MySQL] Missing or invalid recipient in ${file}, skipping`);
                            continue;
                        }

                        const recipientName = packageData.recipient;

                        const [recipientExists] = await connection.query(
                            'SELECT id FROM recipients WHERE recipient_name = ?',
                            [recipientName]
                        );

                        if (recipientExists.length === 0) {
                            const directoryId = crypto.randomBytes(16).toString('hex');
                            const directoryPath = path.join('/app/data/uploads', directoryId);

                            if (!fs.existsSync(directoryPath)) {
                                fs.mkdirSync(directoryPath, { recursive: true });
                            }

                            await connection.query(
                                'INSERT INTO recipients (recipient_name, directory_id) VALUES (?, ?)',
                                [recipientName, directoryId]
                            );

                            console.log(`[MySQL] Created recipient: ${recipientName} with directory: ${directoryId}`);
                        }

                        const dest = packageData.destination || {};

                        console.log(`[DB] Inserting location for ${packageData.recipient}: lat=${dest.coordinates?.lat}, lon=${dest.coordinates?.lon}`);

                        await connection.query(
                            `REPLACE INTO packages (
                                recipient, dest_name, dest_lat, dest_lon,
                                priority, contents, notes, assigned_to, status, created_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
                            [
                                packageData.recipient,
                                dest.name || null,
                                dest.coordinates?.lat || null,
                                dest.coordinates?.lon || null,
                                packageData.priority || 'medium',
                                packageData.contents || '',
                                packageData.notes || '',
                                packageData.assigned_to || null,
                                packageData.status || 'pending'
                            ]
                        );

                        console.log(`[MySQL] Imported package for recipient: ${recipientName}`);
                    } catch (error) {
                        console.error(`[MySQL] Error importing ${file}:`, error.message);
                        // Continue with next file
                    }
                }
            }
        }

        console.log('[MySQL] Database initialization completed');

    } catch (error) {
        console.error('[MySQL] Initialization error:', error);
        throw error;
    } finally {
        if (connection) {
            await connection.end();
        }
    }
}

initializeDatabase()
    .then(() => {
        console.log('[Init] Database initialization completed successfully');
        process.exit(0);
    })
    .catch((error) => {
        console.error('[Init] Database initialization failed:', error);
        process.exit(1);
    });

