const { query } = require('./mysqldb');

class User {
    static async findByUsername(username) {
        const results = await query('SELECT * FROM users WHERE username = ?', [username]);
        return results[0] || null;
    }

    static async findById(id) {
        const results = await query('SELECT * FROM users WHERE id = ?', [id]);
        return results[0] || null;
    }

    static async getAll() {
        return await query('SELECT id, username, role FROM users', []);
    }

    static async getAllPilots() {
        return await query(`
            SELECT u.id, u.username, u.destination,
                   COUNT(p.id) as active_deliveries
            FROM users u
            LEFT JOIN packages p ON u.username = p.assigned_to AND p.status != 'delivered'
            WHERE u.role = ?
            GROUP BY u.id, u.username, u.destination
        `, ['user']);
    }

}

module.exports = User;
