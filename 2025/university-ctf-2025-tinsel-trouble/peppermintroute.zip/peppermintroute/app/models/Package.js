const { query } = require('./mysqldb');
const path = require('path');

const PACKAGES_DIR = '/app/data/packages';

class Package {
    static async getAll() {
        try {
            return await query('SELECT * FROM packages ORDER BY created_at DESC', []);
        } catch (error) {
            console.error('Error fetching all packages:', error);
            throw new Error('Failed to fetch packages');
        }
    }

    static async findByRecipient(recipient) {
        try {
            return await query('SELECT * FROM packages WHERE recipient = ? ORDER BY created_at DESC', [recipient]);
        } catch (error) {
            console.error(`Error finding packages for recipient ${recipient}:`, error);
            throw new Error('Failed to find packages for recipient');
        }
    }

    static async findByAssignedUser(username) {
        try {
            return await query('SELECT * FROM packages WHERE assigned_to = ? ORDER BY created_at DESC', [username]);
        } catch (error) {
            console.error(`Error finding packages for user ${username}:`, error);
            throw new Error('Failed to find packages for user');
        }
    }

    static async assignToUser(recipient, username) {
        try {
            await query('UPDATE packages SET assigned_to = ?, status = ? WHERE recipient = ?', [username, 'in_transit', recipient]);
        } catch (error) {
            console.error(`Error assigning package for recipient ${recipient} to ${username}:`, error);
            throw new Error('Failed to assign package');
        }
    }

    static async create(recipient, dest_name, dest_lat, dest_lon, priority, contents, notes, assigned_to, status) {
        try {
            if (!recipient) {
                throw new Error('Missing required field: recipient');
            }

            await query(
                `REPLACE INTO packages (
                    recipient, dest_name, dest_lat, dest_lon,
                    priority, contents, notes, assigned_to, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
                [
                    recipient,
                    dest_name || null,
                    dest_lat || null,
                    dest_lon || null,
                    priority || 'medium',
                    contents || '',
                    notes || '',
                    assigned_to || null,
                    status || 'pending'
                ]
            );

            return { recipient };
        } catch (error) {
            console.error('Error creating package:', error);
            throw error;
        }
    }


    static async getFiles(recipient) {
        try {
            if (!/^[a-zA-Z0-9-_]+$/.test(recipient)) {
                return [];
            }

            const files = await query(
                'SELECT file_id, filename, uploaded_at FROM file_attachments WHERE recipient = ? ORDER BY uploaded_at DESC',
                [recipient]
            );

            return files;
        } catch (error) {
            console.error(`Error getting files for recipient ${recipient}:`, error);
            return [];
        }
    }

    static async getFileById(fileId) {
        try {
            if (!/^[0-9a-f]{32}$/i.test(fileId)) {
                return null;
            }

            const files = await query(
                'SELECT * FROM file_attachments WHERE file_id = ?',
                [fileId]
            );

            return files[0] || null;
        } catch (error) {
            console.error(`Error getting file by ID ${fileId}:`, error);
            return null;
        }
    }

    static getFilePath(recipient, filename) {
        try {
            if (!/^[a-zA-Z0-9-_]+$/.test(recipient)) {
                throw new Error('Invalid recipient format');
            }

            const sanitizedFilename = filename.replace(/[\\/\\\\]/g, '');

            const filePath = path.join(PACKAGES_DIR, recipient, sanitizedFilename);

            const resolvedPath = path.resolve(filePath);
            const expectedDir = path.resolve(PACKAGES_DIR, recipient);

            if (!resolvedPath.startsWith(expectedDir + path.sep) && resolvedPath !== expectedDir) {
                throw new Error('Invalid file path');
            }

            return filePath;
        } catch (error) {
            console.error(`Error getting file path for ${recipient}/${filename}:`, error);
            throw error;
        }
    }
}

module.exports = Package;
