const { query } = require('./mysqldb');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

class Recipient {
    static async create(recipientName) {
        const directoryId = crypto.randomBytes(16).toString('hex');
        const directoryPath = path.join('/app/data/uploads', directoryId);

        if (!fs.existsSync(directoryPath)) {
            fs.mkdirSync(directoryPath, { recursive: true });
        }

        await query(
            'INSERT INTO recipients (recipient_name, directory_id) VALUES (?, ?)',
            [recipientName, directoryId]
        );

        return { recipientName, directoryId };
    }

    static async getAll() {
        return await query('SELECT * FROM recipients ORDER BY created_at DESC');
    }

    static async findByName(recipientName) {
        const results = await query(
            'SELECT * FROM recipients WHERE recipient_name = ?',
            [recipientName]
        );
        return results[0] || null;
    }

    static async getDirectory(recipientName) {
        const recipient = await this.findByName(recipientName);
        if (!recipient) {
            return null;
        }
        return path.join('/app/data/uploads', recipient.directory_id);
    }

    static async exists(recipientName) {
        const recipient = await this.findByName(recipientName);
        return !!recipient;
    }

    static async delete(recipientName) {
        await query('DELETE FROM recipients WHERE recipient_name = ?', [recipientName]);
    }
}

module.exports = Recipient;
