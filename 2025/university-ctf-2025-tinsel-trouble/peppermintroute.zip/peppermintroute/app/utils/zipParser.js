/*
    Created my own zip parser because I'm afraid of those supply chain attacks.
*/

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');


class ZipParser {
    constructor(zipPath) {
        this.zipPath = zipPath;
        this.buffer = fs.readFileSync(zipPath);
    }

    findEntries() {
        const entries = [];
        let offset = 0;

        while (offset < this.buffer.length - 30) {
            const sig = this.buffer.readUInt32LE(offset);

            if (sig === 0x04034b50) {
                const entry = this.parseLocalFileHeader(offset);
                if (entry) {
                    entries.push(entry);
                    offset = entry.nextOffset;
                } else {
                    offset++;
                }
            } else {
                offset++;
            }
        }

        return entries;
    }

    parseLocalFileHeader(offset) {
        try {
            const signature = this.buffer.readUInt32LE(offset);
            if (signature !== 0x04034b50) return null;

            const version = this.buffer.readUInt16LE(offset + 4);
            const flags = this.buffer.readUInt16LE(offset + 6);
            const compression = this.buffer.readUInt16LE(offset + 8);
            const fileNameLength = this.buffer.readUInt16LE(offset + 26);
            const extraFieldLength = this.buffer.readUInt16LE(offset + 28);
            const compressedSize = this.buffer.readUInt32LE(offset + 18);

            const fileNameStart = offset + 30;
            const fileName = this.buffer.toString('utf8', fileNameStart, fileNameStart + fileNameLength);

            const dataOffset = offset + 30 + fileNameLength + extraFieldLength;
            const dataEnd = dataOffset + compressedSize;

            return {
                fileName: fileName,
                compression: compression,
                compressedSize: compressedSize,
                dataOffset: dataOffset,
                dataEnd: dataEnd,
                nextOffset: dataEnd
            };
        } catch (e) {
            return null;
        }
    }

    extractAll(destDir) {
        const entries = this.findEntries();
        const extractedFiles = [];

        for (const entry of entries) {
            try {
                // Prevent deeply nested directory structures
                const parts = entry.fileName.split('/').filter(p => p);
                if (parts.length > 4) {
                    console.error(`Path too deep: ${entry.fileName}`);
                    continue;
                }

                const fullPath = path.join(destDir, entry.fileName);

                const dir = path.dirname(fullPath);
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }

                const fileData = this.buffer.slice(entry.dataOffset, entry.dataEnd);

                let content;
                if (entry.compression === 0) {
                    content = fileData;
                } else if (entry.compression === 8) {
                    
                    try {
                        content = zlib.inflateRawSync(fileData);
                    } catch (e) {
                        console.error(`Failed to decompress ${entry.fileName}: ${e.message}`);
                        continue;
                    }
                } else {
                    console.error(`Unsupported compression method ${entry.compression} for ${entry.fileName}`);
                    continue;
                }
                
                extractedFiles.push(fullPath);
                fs.writeFileSync(fullPath, content);
                

            } catch (e) {
                console.error(`Error extracting ${entry.fileName}: ${e.message}`);
            }
        }

        return extractedFiles;
    }
}

module.exports = ZipParser;
