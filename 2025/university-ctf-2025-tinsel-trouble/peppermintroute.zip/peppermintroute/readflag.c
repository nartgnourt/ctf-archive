#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    FILE *fp;
    char flag[256];

    setuid(0);

    fp = fopen("/root/flag.txt", "r");
    if (fp == NULL) {
        printf("Error: Could not read flag file\n");
        return 1;
    }

    if (fgets(flag, sizeof(flag), fp) != NULL) {
        printf("%s", flag);
    }

    fclose(fp);
    return 0;
}
