#!/bin/bash
set -e

# Generate random database password
DB_PASSWORD=$(openssl rand -hex 16)
echo "[Setup] Generated random database password"

# Configure MariaDB to listen on 127.0.0.1 and disable host name resolution
mkdir -p /etc/mysql/mariadb.conf.d
cat > /etc/mysql/mariadb.conf.d/99-custom.cnf <<'MARIADB_EOF'
[mysqld]
bind-address = 127.0.0.1
skip-networking = 0
skip-name-resolve = 1
MARIADB_EOF

# Start MySQL temporarily to set password
service mariadb start

for i in {1..30}; do
    if mariadb -u root -e "SELECT 1" &>/dev/null; then
        echo "[Setup] MySQL is ready"
        break
    fi
    echo "[Setup] Waiting for MySQL... ($i/30)"
    sleep 1
done

mariadb -u root <<EOF
CREATE USER IF NOT EXISTS 'root'@'127.0.0.1' IDENTIFIED VIA mysql_native_password;
SET PASSWORD FOR 'root'@'127.0.0.1' = PASSWORD('${DB_PASSWORD}');
GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
EOF

echo "[Setup] Database password configured"

# Wait a moment before stopping to let any background scripts finish
sleep 1

# Kill MariaDB directly instead of using service stop (which needs password)
killall mariadbd mysqld_safe 2>/dev/null || true

# Wait for MariaDB to fully stop
for i in {1..30}; do
    if ! pgrep -x mariadbd > /dev/null; then
        echo "[Setup] MariaDB stopped successfully"
        break
    fi
    sleep 1
done

export DB_PASSWORD

sed -i "s/DB_PASSWORD=\"\"/DB_PASSWORD=\"${DB_PASSWORD}\"/g" /etc/supervisor/conf.d/supervisord.conf

echo "[Setup] Configuration complete"
echo "=========================================="
echo "Database password: ${DB_PASSWORD}"
echo "=========================================="

exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf
