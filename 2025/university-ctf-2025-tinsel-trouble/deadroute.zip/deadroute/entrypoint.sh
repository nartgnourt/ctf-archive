#!/bin/sh

# Generate random ADMIN_PASSWORD (32 characters)
ADMIN_PASSWORD=$(openssl rand -hex 16)
export ADMIN_PASSWORD

# Generate random AUTH_SECRET (32 characters)
AUTH_SECRET=$(openssl rand -hex 16)
export AUTH_SECRET

echo "ADMIN_PASSWORD: $ADMIN_PASSWORD"
echo "AUTH_SECRET: $AUTH_SECRET"

# Execute the application
exec ./deadroute

