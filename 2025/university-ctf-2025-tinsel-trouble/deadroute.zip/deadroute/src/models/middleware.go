package models

import (
	"log"
	"net"
	"net/http"
	"time"
)

func CheckAuth(w http.ResponseWriter, r *http.Request) bool {
	cookie, err := r.Cookie("santa_auth")
	if err != nil || cookie.Value == "" || !VerifyAuthToken(cookie.Value) {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return false
	}
	return true
}

func RequireAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !CheckAuth(w, r) {
			return
		}
		next.ServeHTTP(w, r)
	})
}

func LogMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, r)
		log.Printf("%s %s %v", r.Method, r.URL.Path, time.Since(start))
	})
}

func AntiXSS(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-XSS-Protection", "1; mode=block")
		next.ServeHTTP(w, r)
	})
}

func CSPProtection(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Security-Policy", "default-src 'self' cdn.tailwindcss.com fonts.googleapis.com; script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com; style-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com; img-src 'self' data:; font-src 'self' data: https://fonts.gstatic.com; frame-src 'self'; media-src 'self'; object-src 'none'; form-action 'self'; base-uri 'self';")
		next.ServeHTTP(w, r)
	})
}

func LocalHostOnly(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Extract IP from RemoteAddr (format: "IP:port")
		host, _, err := net.SplitHostPort(r.RemoteAddr)
		if err != nil {
			// If SplitHostPort fails, try using RemoteAddr directly
			host = r.RemoteAddr
		}

		// Check if request is from localhost
		// Handle both IPv4 (127.0.0.1) and IPv6 (::1) cases
		if host != "127.0.0.1" && host != "::1" && host != "localhost" {
			http.Error(w, "Forbidden", http.StatusForbidden)
			return
		}
		next.ServeHTTP(w, r)
	})
}
