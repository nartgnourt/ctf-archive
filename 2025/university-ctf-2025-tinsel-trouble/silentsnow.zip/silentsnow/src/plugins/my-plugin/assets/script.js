// My Plugin JavaScript
(function ($) {
    'use strict';

    $(document).ready(function () {
        console.log('My Plugin loaded');
    });
})(jQuery);