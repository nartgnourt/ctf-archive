// Force puppeteer to store everything to /tmp/
process.env.HOME = "/tmp";

const { delay, handleTargetCreated, handleTargetDestroyed, logMainInfo, logMainError } = require("./utils");
const crypto = require("crypto");
const puppeteer = require("puppeteer");

const APP_ORIGIN = process.env.APP_ORIGIN || "http://web:3000";
const FLAG = process.env.FLAG || "idek{aajvfibuvugeyvjfgskugh}";
const FLAG_FNOTE = `"average ctf solves 3 web a year" factoid actualy just statistical error. average ctf solvers 0 web per year. ${FLAG}, who lives on htb & solves over 10,000 each day, is an outlier adn should not have been counted`;

// Banner
const tips = ["Every console.log usage on the bot will be sent back to you :)", "There is a small race window (~10ms) when a new tab is opened where console.log won't return output :("];
console.log(`==========\nTips: ${tips[Math.floor(Math.random() * tips.length)]}\n==========`);

// Spawn the bot and navigate to the user provided link.
async function goto(url) {
    logMainInfo("Starting the browser...");
    const browser = await puppeteer.launch({
        headless: "new",
        ignoreHTTPSErrors: true,
        args: [
            "--no-sandbox",
            "--disable-gpu",
            "--disable-jit",
            "--disable-wasm",
            "--disable-dev-shm-usage",
            // `--proxy-pac-url=data:application/x-ns-proxy-autoconfig;base64,${PAC_B64}`,
        ],
        executablePath: "/usr/bin/chromium-browser"
    });

    // Hook tabs events
    browser.on("targetcreated", handleTargetCreated.bind(browser));
    browser.on("targetdestroyed", handleTargetDestroyed.bind(browser));

    /* ** CHALLENGE LOGIC ** */
    const ctx = await browser.createBrowserContext();
    let page = await ctx.newPage();
    await page.setDefaultNavigationTimeout(5000);

    const username = crypto.randomBytes(16).toString("hex");
    const password = crypto.randomBytes(16).toString("hex");

    logMainInfo("Creating flag fnote...");

    await page.goto(`${APP_ORIGIN}/login`);
    await page.waitForSelector('input[name="username"]');
    await page.type('input[name="username"]', username);
    await page.type('input[name="password"]', password);
    await page.click('input[type="submit"]');
    await page.waitForNavigation({ waitUntil: "networkidle2" });

    await page.goto(`${APP_ORIGIN}/notes/create`);
    await page.waitForSelector('textarea[name="content"]');
    await page.type('textarea[name="content"]', FLAG_FNOTE);
    await Promise.all([
        page.click('input[type="submit"]'),
        page.waitForNavigation({ waitUntil: "networkidle2" }),
    ]);
    const content = await page.content();
    if (!content.includes(FLAG)) {
        logMainError("Flag note not set, please open a ticket");
        await browser.close();
        return;
    }
    await page.close();

    logMainInfo("Going to the user provided link...");
    page = await ctx.newPage();
    await page.setDefaultNavigationTimeout(5000);
    await page.goto(url);
    await delay(120_000);

    logMainInfo("Leaving o/");
    await browser.close();
    return;
}

// Handle TCP data
process.stdin.on("data", (data) => {
    const url = data.toString().trim();

    if (!url || !(url.startsWith("http://") || url.startsWith("https://"))) {
        logMainError("You provided an invalid URL. It should start with http:// or https://.");
        process.exit(1);
    }

    goto(url)
    .then(() => process.exit(0))
    .catch((error) => {
        if (process.env.ENVIRONMENT === "development") {
            console.error(error);
        }
        process.exit(1);
    });
});