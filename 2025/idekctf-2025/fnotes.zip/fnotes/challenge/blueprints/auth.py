from flask import *
from db import *
from middleware import login_required

auth_bp = Blueprint("auth", __name__, url_prefix="/")

@auth_bp.route("/login", methods=["GET", "POST"])
# csrf-exempt
def login():
	if "user" in session:
		return redirect(url_for("notes.index"))

	if request.method == "POST":
		username = request.form.get("username", "").strip()
		password = request.form.get("password", "")

		if not username or not password:
			flash("username and password are required", "error")
			return redirect(url_for("auth.login"))

		user_id = get_user_id(username)
		if user_id and verify_user(user_id, password):
			session["user"] = user_id
			flash("login successful", "success")
			return redirect(url_for("notes.index"))

		elif user_id is not None:
			flash("invalid credentials", "error")
			return redirect(url_for("auth.login"))

		if len(username) < 5 or len(username) > 32:
			flash("username must be between 5 and 32 characters long", "error")
			return redirect(url_for("auth.login"))

		if not username.isalnum():
			flash("username must be alphanumeric", "error")
			return redirect(url_for("auth.login"))

		if len(password) < 8 or len(password) > 128:
			flash("password must be between 8 and 128 characters long", "error")
			return redirect(url_for("auth.login"))

		user_id = create_user(username, password)
		if user_id is not None:
			session["user"] = user_id
			flash("account created and logged in successfully", "success")
			return redirect(url_for("notes.index"))
		else:
			flash("failed to create account", "error")
		return redirect(url_for("auth.login"))

	return render_template("login.html")

@auth_bp.route("/logout")
@login_required
def logout():
	session.pop("user", None)
	flash("logged out successfully", "success")
	return redirect(url_for("auth.login"))
