# ctf: you can assume this is all fine

import sqlite3
from flask import g
import hashlib
import os

DATABASE = "users.db"

def get_db():
	if "db" not in g:
		g.db = sqlite3.connect(
			DATABASE,
			detect_types=sqlite3.PARSE_DECLTYPES
		)
		g.db.row_factory = sqlite3.Row
	return g.db

def close_db(e=None):
	db = g.pop("db", None)
	if db is not None:
		try:
			if e is None:
				db.commit()
			else:
				db.rollback()
		finally:
			db.close()

def hash_password(password):
	return hashlib.sha256(password.encode()).hexdigest()

def init_db():
	with sqlite3.connect(DATABASE) as conn:
		with open("schema.sql", "r") as f:
			conn.executescript(f.read())
		conn.commit()

def create_user(username, password):
	try:
		user_id = os.urandom(16).hex()
		get_db().execute(
			"INSERT INTO users (user_id, username, password_hash) VALUES (?, ?, ?)",
			(user_id, username, hash_password(password))
		)
		return user_id
	except sqlite3.IntegrityError:
		return None

def verify_user(user_id, password):
	user = get_db().execute(
		"SELECT password_hash FROM users WHERE user_id = ?",
		(user_id,)
	).fetchone()
	if user and user["password_hash"] == hash_password(password):
		return True
	return False

def get_user_id(username):
	row = get_db().execute(
		"SELECT user_id FROM users WHERE username = ?",
		(username,)
	).fetchone()
	return row["user_id"] if row else None

def get_user(user_id):
	return get_db().execute(
		"SELECT user_id, username FROM users WHERE user_id = ?",
		(user_id,)
	).fetchone()

def has_sent_friend_request(from_user_id, to_user_id):
	row = get_db().execute(
		"SELECT 1 FROM friend_requests WHERE from_user_id = ? AND to_user_id = ?",
		(from_user_id, to_user_id)
	).fetchone()
	return bool(row)

def get_friend_requests(to_user_id):
	return get_db().execute("""
		SELECT u.user_id, u.username
		FROM friend_requests fr
		JOIN users u ON fr.from_user_id = u.user_id
		WHERE fr.to_user_id = ?
	""", (to_user_id,)).fetchall()

def send_friend_request(from_user_id, to_user_id):
	if from_user_id == to_user_id:
		return
	get_db().execute(
		"INSERT OR IGNORE INTO friend_requests (from_user_id, to_user_id) VALUES (?, ?)",
		(from_user_id, to_user_id)
	)

def accept_friend_request(from_user_id, to_user_id):
	user1, user2 = sorted([from_user_id, to_user_id])
	conn = get_db()
	conn.execute(
		"DELETE FROM friend_requests WHERE from_user_id = ? AND to_user_id = ?",
		(from_user_id, to_user_id)
	)
	conn.execute(
		"INSERT OR IGNORE INTO friendships (user1_id, user2_id) VALUES (?, ?)",
		(user1, user2)
	)

def get_friends(user_id):
	return get_db().execute("""
		SELECT u.user_id, u.username
		FROM friendships f
		JOIN users u ON (
			(u.user_id = f.user1_id AND f.user2_id = ?) OR
			(u.user_id = f.user2_id AND f.user1_id = ?)
		)
		WHERE u.user_id != ?
	""", (user_id, user_id, user_id)).fetchall()

def are_friends(user1_id, user2_id):
	user1_id, user2_id = sorted([user1_id, user2_id])
	row = get_db().execute(
		"SELECT 1 FROM friendships WHERE user1_id = ? AND user2_id = ?",
		(user1_id, user2_id)
	).fetchone()
	return bool(row)

def create_note(user_id, content):
	note_id = os.urandom(16).hex()
	get_db().execute(
		"INSERT INTO notes (note_id, user_id, content) VALUES (?, ?, ?)",
		(note_id, user_id, content)
	)
	return note_id

def get_note(note_id):
	return get_db().execute("""
		SELECT
			p.note_id,
			p.content,
			p.created_at,
			p.user_id,
			u.username
		FROM notes p
		JOIN users u ON p.user_id = u.user_id
		WHERE p.note_id = ?
	""", (note_id,)).fetchone()

def delete_note(note_id):
	get_db().execute(
		"DELETE FROM notes WHERE note_id = ?",
		(note_id,)
	)

def get_visible_notes(user_id):
	return get_db().execute("""
		SELECT
			p.note_id,
			p.content,
			p.created_at,
			p.user_id,
			u.username
		FROM notes p
		JOIN users u ON p.user_id = u.user_id
		WHERE p.user_id = ?
			OR p.user_id IN (
				SELECT CASE
					WHEN f.user1_id = ? THEN f.user2_id
					ELSE f.user1_id
				END
				FROM friendships f
				WHERE f.user1_id = ? OR f.user2_id = ?
			)
		ORDER BY p.created_at DESC
	""", (user_id, user_id, user_id, user_id)).fetchall()
