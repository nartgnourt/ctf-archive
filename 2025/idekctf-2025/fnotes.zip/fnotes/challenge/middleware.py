from functools import wraps
from flask import *
from db import *

def login_required(f):
	@wraps(f)
	def fn(*args, **kwargs):
		if "user" not in session:
			flash("please log in first", "error")
			return redirect(url_for("auth.login"))
		g.user = get_user(session["user"])
		return f(*args, **kwargs)
	return fn
