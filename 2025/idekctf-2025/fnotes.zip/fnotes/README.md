- this challenge uses mizu's bot (https://github.com/kevin-mizu/bot-ctf-template) with only `console.log` output, timeout 120s, and tabs limit set to 100, but you realistically shouldn't hit either of those
- the intended solution does not involve a server-side dos

have fun :)
