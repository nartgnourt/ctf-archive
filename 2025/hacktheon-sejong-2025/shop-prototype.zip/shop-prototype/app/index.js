const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const _ = require('lodash'); 
const port = 3000;
const db = require('./db');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const { sanitize } = require('./utils/sanitizer')
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
}));

let flag = process.env.FLAG;

function createUserContext(data) {
  const baseUser = {}
  const user = Object.create(baseUser);
  user.id = data.id;
  user.username = data.username;
  user.points = data.points;
  user.purchased = [];
  return user;
}

app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.stack);
  res.status(500).send("Something went wrong. Please try again later.");
});

app.get('/', (req, res) => {
  res.send('Welcome to the Prototype Shop!');
});

function requireLogin(req, res, next) {
  if (!req.session.userId) return res.status(401).send("Login required");
  next();
}

app.post('/auth/logout', requireLogin, (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).send("Could not log out");
    }
    res.clearCookie('connect.sid');
    res.send("Logout successful!");
  });
});

app.get('/auth/register', (req, res) => {
  res.send('Register page');
});

app.post('/auth/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).send("Missing fields");
  
  const [exists] = await db.execute('SELECT * FROM users WHERE username = ?', [username]);
  if (exists.length > 0) return res.status(400).send("User already exists");

  const hashedPassword = await bcrypt.hash(password, 10);
  await db.execute('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword]);

  res.send("User registered successfully!");
});

app.get('/auth/login', (req, res) => {
  res.send('Login page');
});

app.post('/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const [rows] = await db.execute('SELECT * FROM users WHERE username = ?', [username]);
  if (rows.length === 0) return res.status(400).send("Invalid username or password");

  const userRow = rows[0];
  const isValidPassword = await bcrypt.compare(password, userRow.password);
  if (!isValidPassword) return res.status(400).send("Invalid username or password");

  req.session.userId = userRow.id;
  req.session.user = createUserContext(userRow);
  res.send("Login successful!");

})

app.get('/products', requireLogin, async (req, res) => {
  const [products] = await db.execute('SELECT * FROM products'); 
  res.json(products);
});

app.get('/me', requireLogin, async (req, res) => {
  const user = req.session.user;
  
  res.json({
    id: user.id,
    username: user.username,
    points: user.points,
    verified: user.verified,
    status: user.state,
    purchased: user.purchased
  });
});

app.post('/payment/init', requireLogin, async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM users WHERE id = ?', [req.session.userId]);
  if (rows.length === 0) return res.status(404).send("User not found");

  const user = req.session.user;

  const forbiddenKeys = ['verified', 'status'];
  for (const key of forbiddenKeys) {
    if (key in req.body) {
      return res.status(400).send("[✖] You cannot modify this field. : {" + key + "}");
    }
  }

  const cleanBody = sanitize(req.body)
  _.merge(user, cleanBody);
  res.send("[✔] Info merged for payment.");
});


app.get('/payment/confirm', requireLogin, async (req, res) => {
  const user = req.session.user;
  if (!user || !user.productId) return res.status(400).send("Missing payment info.");

  const [products] = await db.execute('SELECT * FROM products WHERE id = ?', [user.productId]);
  if (products.length === 0) return res.status(404).send("Product not found");

  const product = products[0];

  const user_points = user.points;
  if (user_points < product.price) {
    return res.status(400).send("Not enough points.");
  }

  if (user.verified === true && user.state === 'paid' ) {
    await db.execute('UPDATE users SET points = points - ? WHERE id = ?', [product.price, user.id]);
    await db.execute('INSERT INTO purchases (user_id, product_id) VALUES (?, ?)', [user.id, product.id]);
    return res.send("🎉 Congratulations! " + flag);
  }
  return res.status(403).send("Prototype Shop: You’ve reached the limits of this early-stage system. No real purchases can be made.");
});

app.listen(port, () => {
  console.log(`SSPP true-prototype challenge running on http://localhost:${port}`);
});
