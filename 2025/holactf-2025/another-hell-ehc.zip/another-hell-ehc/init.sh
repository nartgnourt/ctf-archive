#!/bin/sh
if [ -n "$GZCTF_FLAG" ]; then
    echo "$GZCTF_FLAG" > /flag.txt 2>/dev/null || true && \
    chmod 444 /flag.txt 2>/dev/null || true && \
    unset GZCTF_FLAG 2>/dev/null || true
fi

/usr/bin/supervisord -c /etc/supervisor/supervisord.conf