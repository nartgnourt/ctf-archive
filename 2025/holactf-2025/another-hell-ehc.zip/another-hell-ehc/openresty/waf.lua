-- WAF Script for file upload filtering
ngx.log(ngx.ERR, "WAF: Starting file upload inspection")

-- Read the request body
ngx.req.read_body()
local body = ngx.req.get_body_data()

-- If body is nil, try to get it from file (for large uploads)
if not body then
    local body_file = ngx.req.get_body_file()
    if body_file then
        local file = io.open(body_file, "r")
        if file then
            body = file:read("*all")
            file:close()
        end
    end
end

if not body then
    ngx.log(ngx.ERR, "WAF: No body data found")
    ngx.status = 400
    ngx.say("Missing body")
    return ngx.exit(400)
end

ngx.log(ngx.ERR, "WAF: Body size: " .. string.len(body))

-- Extract filename from multipart form data
local filename = body:match('filename="([^"]+)"')
if filename then
    ngx.log(ngx.ERR, "WAF: Found filename: " .. filename)
    
    -- Extract file extension
    local ext = filename:match("%.([^.]+)$")
    if ext then
        ngx.log(ngx.ERR, "WAF: File extension: " .. ext)
        
        -- Define allowed extensions
        local allowed = {
            jpg = true,
            jpeg = true,
            png = true,
            gif = true
        }

        -- Check if extension is allowed
        if not allowed[ext:lower()] then
            ngx.log(ngx.ERR, "WAF: Blocked extension: " .. ext)
            ngx.status = 403
            ngx.say("Blocked: file extension not allowed - " .. ext)
            return ngx.exit(403)
        else
            ngx.log(ngx.ERR, "WAF: Extension allowed: " .. ext)
        end
    else
        ngx.log(ngx.ERR, "WAF: No file extension found")
        ngx.status = 400
        ngx.say("Blocked: no file extension")
        return ngx.exit(400)
    end
else
    ngx.log(ngx.ERR, "WAF: No filename found in request")
end

-- Additional content type validation
local content_type = ngx.var.content_type
if content_type then
    ngx.log(ngx.ERR, "WAF: Content-Type: " .. content_type)
    if not content_type:match("multipart/form%-data") then
        ngx.log(ngx.ERR, "WAF: Invalid content type")
        ngx.status = 400
        ngx.say("Blocked: invalid content type")
        return ngx.exit(400)
    end
end

ngx.log(ngx.ERR, "WAF: File upload passed all checks")
