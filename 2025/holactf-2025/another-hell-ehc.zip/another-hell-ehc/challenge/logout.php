<?php
// Prevent direct access - must come through index.php
if (!defined('SECURE_ACCESS')) {
    die('Direct access not allowed. Please use /?page=logout');
}

session_start();
session_destroy();
echo 'You have been logged out. Wait a minute to redirect to the login page';
header('Location: /?page=login');
?>