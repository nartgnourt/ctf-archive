<?php
// Prevent direct access - must come through index.php
if (!defined('SECURE_ACCESS')) {
  die('Direct access not allowed. Please use /?page=upload');
}

require 'database.php';
ini_set('display_errors', '0'); 
header('Content-Type: text/html; charset=UTF-8');

session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
  header('Location: /?page=login');
  exit;
}

$conn = new Database();


$target_dir = "upload/" . $_SESSION['username'] . "/";
if (!is_dir($target_dir)) {
  mkdir($target_dir, 0777, true);
}

$allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

if (isset($_FILES['avatar']['full_path']) && !empty($_FILES['avatar']['full_path'])) {
  $fileName = $_FILES['avatar']['full_path'];
} else {
  $fileName = $_FILES['avatar']['name'];
}
// Check if file already exists
if (file_exists($target_dir . $fileName)) {
  exit("Sorry, file already exists.");
}

$fileExt = explode('.', basename($fileName))[1];

$target_file = $target_dir . $fileName;

if (!in_array($fileExt, $allowedExtensions)) {
  exit("Sorry, your file type is not allowed.");
}

if ($_FILES["avatar"]["size"] > 5000000) {
  exit("Sorry, your file is too large.");
}

if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $target_file)) {
  $conn->updateAvatar($_SESSION['username'], $fileName);
  header('Location: /?page=home');
}

