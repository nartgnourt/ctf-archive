package main

import (
	"crypto/rand"
	"encoding/hex"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"
)

type unixDialer struct {
	net.Dialer
}

func (d *unixDialer) Dial(network, address string) (net.Conn, error) {
	return d.Dialer.Dial("unix", "/tmp/ds-"+strings.Split(address, ":")[0]+".socket")
}

var transport http.RoundTripper = &http.Transport{
	Proxy: http.ProxyFromEnvironment,
	Dial:  (&unixDialer{net.Dialer{Timeout: 5 * time.Second}}).Dial,
}

var backends sync.Map

func NewDS(config []string) string {
	bytes := make([]byte, 32)
	if _, err := rand.Read(bytes); err != nil {
		return ""
	}
	session := hex.EncodeToString(bytes)
	config = append(config, "SESSION="+session)

	go func() {
		cmd := exec.Command("./ds")
		cmd.Env = append(os.Environ(), config...)

		cmd.Run()
		backends.Delete(session)
	}()

	url, err := url.Parse("http://" + session)
	if err != nil {
		return ""
	}
	proxy := httputil.NewSingleHostReverseProxy(url)
	proxy.Transport = transport

	backends.Store(session, proxy)
	return session
}

func main() {
	http.HandleFunc("POST /", func(w http.ResponseWriter, r *http.Request) {
		r.ParseForm()

		fields := []string{}
		for key, value := range r.Form {
			fields = append(fields, key+"="+strings.Join(value, ","))
		}

		cookie := &http.Cookie{Name: "session", Value: NewDS(fields), Path: "/", Expires: time.Now().Add(180 * time.Second)}
		http.SetCookie(w, cookie)
		time.Sleep(time.Second * 2)
		http.Redirect(w, r, "/", http.StatusFound)
	})

	http.HandleFunc("GET /", func(w http.ResponseWriter, r *http.Request) {
		session := ""
		if cookie, err := r.Cookie("session"); err == nil {
			session = cookie.Value
		}

		proxy, ok := backends.Load(session)

		if !ok {
			w.Write([]byte(`<html><h1>Dateiservierer</h1>
			<label>Files</label>
			<button onclick="window.form.innerHTML = '<input name=files><br>' + window.form.innerHTML">➕</button>
			<form method=POST id=form>
				<input name=files value=index.html><br>
				<input type=submit value="Bitte servieren Sie">
			</form>
			`))
			return
		}
		proxy.(*httputil.ReverseProxy).ServeHTTP(w, r)
	})

	srv := &http.Server{
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 5 * time.Second,
		IdleTimeout:  10 * time.Second,
		Handler:      http.DefaultServeMux,
		Addr:         ":1024",
	}
	log.Println(srv.ListenAndServe())
}
