package main

import (
	"io"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

var files = strings.Split(os.Getenv("files"), ",")

var client = &http.Client{
	Timeout: 5 * time.Second,
}

func fileHandler(w http.ResponseWriter, req *http.Request) {
	fileIndex, _ := strconv.Atoi(req.URL.Query().Get("file"))
	filePath := files[fileIndex%len(files)]

	if strings.Contains(filePath, "flag") {
		http.Error(w, "flag :(", http.StatusUnauthorized)
		return
	}

	var fd io.ReadSeekCloser

	if strings.HasPrefix(filePath, "http://") || strings.HasPrefix(filePath, "https://") {
		resp, err := client.Get(filePath)
		if err != nil {
			http.Error(w, "Get :(", http.StatusInternalServerError)
			return
		}
		defer resp.Body.Close()

		tempFile, err := os.CreateTemp("", "download")
		if err != nil {
			http.Error(w, "CreateTemp :(", http.StatusInternalServerError)
			return
		}
		defer os.Remove(tempFile.Name())
		io.Copy(tempFile, io.LimitReader(resp.Body, 8*1024*1024))

		fd = tempFile
	} else {
		file, err := os.Open(filePath)
		if err != nil {
			http.Error(w, "Open :(", http.StatusInternalServerError)
			return
		}
		fd = file
	}

	defer fd.Close()

	r, _ := strconv.ParseInt(req.URL.Query().Get("resume"), 10, 64)
	fd.Seek(r, io.SeekStart)
	io.Copy(w, io.LimitReader(fd, 8*1024*1024))
}

func main() {
	time.AfterFunc(180*time.Second, func() {
		os.Exit(0)
	})
	session, ok := os.LookupEnv("SESSION")
	if !ok {
		panic("SESSION env not set")
	}

	http.HandleFunc("GET /", fileHandler)
	unixListener, err := net.Listen("unix", "/tmp/ds-"+session+".socket")
	if err != nil {
		panic(err)
	}
	http.Serve(unixListener, nil)
}
