package main

import (
	"database/sql"
	_ "embed"
	"net/http"
	"os"
	"strconv"
	"sync"
	"text/template"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

type User struct {
	ID     int64
	Name   string
	Credit uint64
}

type transactions struct {
	Sender   int64
	Receiver int64
	Amount   uint64
}

//go:embed index.html
var indexHtml string
var tmpl = template.Must(template.New("index.html").Parse(indexHtml))

var db *sql.DB

//go:embed schema.sql
var dbSchema string

func initDB() {
	db, _ = sql.Open("mysql", "user:password@tcp(db)/db?multiStatements=true")

	db.SetConnMaxLifetime(time.Minute * 5)
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)

	db.Exec(dbSchema)
}

func Sum(userID int64) uint64 {
	if userID == 1 { // System is always bankrupt :/
		return 0
	}

	rows, _ := db.Query("SELECT amount, receiver, sender FROM transactions")
	defer rows.Close()

	var sum uint64

	for rows.Next() {
		transactions := transactions{}
		rows.Scan(&transactions.Amount, &transactions.Receiver, &transactions.Sender)

		if transactions.Receiver == userID {
			sum += transactions.Amount
		} else if transactions.Sender == userID {
			sum -= transactions.Amount
		}
	}

	return sum
}

func main() {
	initDB()

	// Sorry, I still haven't learned DB transactions :/
	var mutex sync.Mutex

	http.HandleFunc("GET /", func(w http.ResponseWriter, r *http.Request) {
		mutex.Lock()
		defer mutex.Unlock()

		rows, _ := db.Query("SELECT name, id FROM users")
		defer rows.Close()
		var users []User

		for rows.Next() {
			user := User{}
			rows.Scan(&user.Name, &user.ID)
			users = append(users, user)
		}

		for i := range users {
			users[i].Credit = Sum(users[i].ID)
		}

		tmpl.Execute(w, struct {
			Msg   string
			Users []User
		}{
			r.URL.Query().Get("msg"),
			users,
		})
	})

	demoUserLimit := 5
	http.HandleFunc("POST /signup", func(w http.ResponseWriter, r *http.Request) {
		mutex.Lock()
		defer mutex.Unlock()

		if demoUserLimit <= 0 {
			http.Redirect(w, r, "/?msg=Demo+Version+Limit+Reached", http.StatusFound)
			return
		}
		demoUserLimit -= 1

		r.ParseForm()

		res, _ := db.Exec("INSERT INTO users (name, id) VALUES (?, ?)", r.Form.Get("name"), r.Form.Get("id"))
		id, _ := res.LastInsertId()
		db.Exec("INSERT INTO transactions (subject, amount, sender, receiver) VALUES (?, ?, ?, ?)", "Gift from the system", 10, 1, id)

		http.Redirect(w, r, "/?msg=User+Created", http.StatusFound)
	})

	http.HandleFunc("POST /transfer", func(w http.ResponseWriter, r *http.Request) {
		mutex.Lock()
		defer mutex.Unlock()

		r.ParseForm()

		sender, _ := strconv.ParseInt(r.Form.Get("sender"), 10, 64)
		amount, _ := strconv.ParseUint(r.Form.Get("amount"), 10, 64)

		sum := Sum(sender)

		if sum < amount {
			http.Redirect(w, r, "/?msg=Too+Poor+For+Transfer", http.StatusFound)
			return
		}

		db.Exec("INSERT INTO transactions (receiver, sender, subject, amount) VALUES (?, ?, ?, ?)", r.Form.Get("receiver"), sender, r.Form.Get("subject"), amount)
		http.Redirect(w, r, "/?msg=Transferred", http.StatusFound)
	})

	http.HandleFunc("POST /flag", func(w http.ResponseWriter, r *http.Request) {
		mutex.Lock()
		defer mutex.Unlock()

		r.ParseForm()

		id, _ := strconv.ParseInt(r.Form.Get("id"), 10, 64)
		sum := Sum(id)
		if sum >= 1337 {
			flag, _ := os.ReadFile("flag.txt")

			http.Redirect(w, r, "/?msg="+string(flag), http.StatusFound)
			return
		}

		http.Redirect(w, r, "/?msg=Too+Poor+For+Flag", http.StatusFound)
	})

	http.ListenAndServe(":13371", nil)
}
