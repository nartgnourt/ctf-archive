
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id SERIAL,
    name VARCHAR(255)
);
INSERT INTO users(name, id) VALUES ('System', 1);

CREATE TABLE transactions (
    sender BIGINT unsigned NOT NULL,
    subject VARCHAR(255) NOT NULL,
    amount BIGINT unsigned NOT NULL,
    receiver BIGINT unsigned NOT NULL,
    FOREIGN KEY (sender) REFERENCES users(id),
    FOREIGN KEY (receiver) REFERENCES users(id),
    CHECK (receiver <> sender)
);