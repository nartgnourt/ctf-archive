<?php
header(
    "Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self'; font-src 'self'; img-src 'self' data:",
);

require __DIR__ . "/../auth.php";
require __DIR__ . "/../config.php";

$flag = file_get_contents("/flag.txt");

$rows = $pdo
    ->query(
        "SELECT *
        FROM visits
        ORDER BY created_at DESC, id DESC
        LIMIT 100",
    )
    ->fetchAll();

$osCount = $pdo
    ->query(
        "SELECT os_name as name, COUNT(*) AS value
        FROM visits
        GROUP BY name
        ORDER BY value DESC",
    )
    ->fetchAll();

$deviceCount = $pdo
    ->query(
        "SELECT device_name as name, COUNT(*) AS value
        FROM visits
        GROUP BY name
        ORDER BY value DESC",
    )
    ->fetchAll();

$clientCount = $pdo
    ->query(
        "SELECT client_name as name, COUNT(*) AS value
        FROM visits
        GROUP BY name
        ORDER BY value DESC",
    )
    ->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Device OS Stats</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/mermaid.min.css">
    <link rel="stylesheet" href="/css/fa.min.css">
  </head>
  <body>
    <h1>Device OS Stats</h1>
    <p><?= $flag ?></p>

    <div class="row">
      <div id="deviceChart" class="chart"></div>
      <div id="osChart" class="chart"></div>
      <div id="clientChart" class="chart"></div>
    </div>

    <h2>Last 100 visits</h2>
    <div id="table"></div>

    <script src="/js/echarts.min.js"></script>
    <script src="/js/gridjs.umd.js"></script>

    <script>
    const tooltip = {
        trigger: 'item',
        backgroundColor: '#222',
        borderColor: '#444',
        textStyle: {
            color: '#fff'
        },
        formatter: function(params) {
            return `
                <div style="padding:6px">
                    <strong>${params.name}</strong><br>
                    Count: ${params.value}<br>
                    Share: ${params.percent}%
                </div>
            `;
        }
    }

    new gridjs.Grid({
        columns: ['Timestamp', 'Device', 'OS', 'Client', 'Raw'],
        sort: true,
        resizable: true,
        data: [
            <?php foreach ($rows as $row): ?>
            ["<?= $row["created_at"] ?>", gridjs.html('<i class="<?= [
                "desktop" => "fa-solid fa-computer",
                "smartphone" => "fa-solid fa-mobile-screen",
                "tablet" => "fa-solid fa-tablet-screen-button",
                "feature phone" => "fa-solid fa-mobile-screen",
                "console" => "fa-solid fa-gamepad",
                "tv" => "fa-solid fa-tv",
                "car browser" => "fa-solid fa-car",
                "smart display" => "fa-solid fa-desktop",
                "camera" => "fa-regular fa-camera",
                "portable media player" => "fa-solid fa-circle-play",
                "phablet" => "fa-solid fa-tablet-screen-button",
                "smart speaker" => "fa-solid fa-headphones",
                "wearable" => "fa-regular fa-clock",
                "peripheral" => "fa-solid fa-computer-mouse",
            ][$row["device_name"]] ?>"></i>'), "<?= htmlspecialchars($row["os_name"]) . " " . $row["os_version"] ?>", "<?= htmlspecialchars($row["client_name"]) . " " . $row["client_version"] ?>",""],
            <?php endforeach; ?>
        ]
    }).render(document.getElementById('table'));

    let osChart = echarts.init(document.getElementById('osChart'));
    osChart.setOption({
        title: {
            text: 'OS Distribution',
            left: 'center'
        },
        tooltip: tooltip,
        series: [{
            type: 'pie',
            radius: '60%',
            data: <?= json_encode($osCount) ?>,
        }]
    });

    let deviceChart = echarts.init(document.getElementById('deviceChart'));
    deviceChart.setOption({
        title: {
            text: 'Device Type Distribution',
            left: 'center'
        },
        tooltip: tooltip,
        series: [{
            type: 'pie',
            radius: '60%',
            data: <?= json_encode($deviceCount) ?>,
        }]
    });

    let clientChart = echarts.init(document.getElementById('clientChart'));
    clientChart.setOption({
        title: {
            text: 'Client Name Distribution',
            left: 'center'
        },
        tooltip: tooltip,
        series: [{
            type: 'pie',
            radius: '60%',
            data: <?= json_encode($clientCount) ?>,
        }]
    });
    </script>
</body>
</html>
