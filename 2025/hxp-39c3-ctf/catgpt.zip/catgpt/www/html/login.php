<?php
session_start();
require __DIR__ . "/../config.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"] ?? "";
    $password = $_POST["password"] ?? "";

    $stmt = $pdo->prepare("
        SELECT password
        FROM admin
        WHERE name = :name
        LIMIT 1
    ");

    $stmt->execute([':name' => $username]);

    $row = $stmt->fetch();

    if ($row && password_verify($password, $row['password'])) {
        $_SESSION["user"] = $username;
        header("Location: stats.php");
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login – Device OS Stats</title>
</head>
<body>
    <h1>Login</h1>

    <?php if ($error): ?>
        <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="post" action="login.php">
        <label>
            Username:
            <input type="text" name="username" required>
        </label><br><br>

        <label>
            Password:
            <input type="password" name="password" required>
        </label><br><br>

        <button type="submit">Log in</button>
    </form>
</body>
</html>
