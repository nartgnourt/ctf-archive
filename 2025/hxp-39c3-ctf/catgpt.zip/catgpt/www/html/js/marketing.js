
document.getElementById("report-button").href = window.location.protocol + '//' + window.location.hostname + ':1337';
