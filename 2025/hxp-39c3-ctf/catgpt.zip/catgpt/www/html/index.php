<?php
header(
    "Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self'; font-src https://cdnjs.cloudflare.com",
);

require __DIR__ . "/../config.php";
require __DIR__ . "/../vendor/autoload.php";

use DeviceDetector\DeviceDetector;

$userAgent = $_SERVER["HTTP_USER_AGENT"] ?? "";

if (!empty($userAgent)) {
    $dd = new DeviceDetector($userAgent);
    $dd->parse();

    $osInfo = $dd->getOs();
    $clientInfo = $dd->getClient();

    $stmt = $pdo->prepare(
        "INSERT INTO visits
            (bot, device_name, os_name, os_version, client_name, client_version, user_agent)
        VALUES
            (:bot, :device_name, :os_name, :os_version, :client_name, :client_version, :user_agent)",
    );
    $stmt->execute([
        ":bot" => $dd->isBot() ? "1" : "0",
        ":device_name" => $dd->getDeviceName() ?? "Unknown",
        ":os_name" => $osInfo["name"] ?? "Unknown",
        ":os_version" => $osInfo["version"] ?? "",
        ":client_name" => $clientInfo["name"] ?? "Unknown",
        ":client_version" => $clientInfo["version"] ?? "",
        ":user_agent" => $userAgent,
    ]);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CatGPT - Artificial Intelligence Meets Feline Intelligence</title>
  <link rel="stylesheet" href="/css/marketing.css">
</head>
<body>
  <div class="container">
    <header>
      <div class="hero-emoji">🐱✨</div>
      <h1>CatGPT</h1>
      <h2>The World's First AI Trained Exclusively on Feline Logic</h2>
    </header>

    <section>
      <span class="pill">Revolutionary Technology</span>
      <h3>Why CatGPT?</h3>
      <p>
        Traditional AI models are trained on human data, leading to predictable, boring responses.
        CatGPT changes everything by leveraging billions of hours of cat behavior, meows, and
        inexplicable decision-making patterns to create truly unique AI interactions.
      </p>

      <div class="feature-grid">
        <div class="feature-card">
          <h4>🎯 Unpredictable Intelligence</h4>
          <p>
            Unlike conventional AI, CatGPT may ignore your questions entirely, knock your
            coffee off the desk, or demand attention at 3 AM. This creates a more authentic
            and engaging user experience.
          </p>
        </div>

        <div class="feature-card">
          <h4>😴 Advanced Sleep Algorithms</h4>
          <p>
            CatGPT spends 70% of its computational cycles in sleep mode, ensuring maximum
            energy efficiency. When awake, it delivers responses with unmatched feline precision.
          </p>
        </div>

        <div class="feature-card">
          <h4>🐭 Laser-Focused on What Matters</h4>
          <p>
            Trained to prioritize the truly important things in life: chasing red dots,
            investigating empty boxes, and maintaining an air of mysterious superiority.
          </p>
        </div>
      </div>
    </section>

    <section>
      <span class="pill">Core Features</span>
      <h3>What CatGPT Can Do For You</h3>

      <div class="feature-grid">
        <div class="feature-card">
          <h4>Selective Responsiveness</h4>
          <ul>
            <li>Sometimes answers immediately</li>
            <li>Sometimes stares blankly at you</li>
            <li>Occasionally walks away mid-conversation</li>
            <li>Always on its own schedule</li>
          </ul>
        </div>

        <div class="feature-card">
          <h4>Emotional Intelligence</h4>
          <ul>
            <li>Masters of passive-aggressive behavior</li>
            <li>Expert-level silent judgement</li>
            <li>Unprompted displays of affection</li>
            <li>Perfectly timed interruptions</li>
          </ul>
        </div>

        <div class="feature-card">
          <h4>Physical Computing</h4>
          <ul>
            <li>Keyboard-sitting optimization</li>
            <li>Strategic object displacement</li>
            <li>Screen-blocking algorithms</li>
            <li>Purring-based error handling</li>
          </ul>
        </div>
      </div>
    </section>

    <section>
      <span class="pill">Enterprise Ready</span>
      <h3>Perfect for Teams</h3>

      <div class="feature-grid">
        <div class="feature-card">
          <h4>🏢 Corporate Integration</h4>
          <p>
            CatGPT seamlessly integrates into your workplace by napping on important documents,
            attending meetings uninvited, and providing unsolicited opinions through interpretive
            meowing.
          </p>
        </div>

        <div class="feature-card">
          <h4>📊 Data Analytics</h4>
          <p>
            Track important metrics like naps per day, treats received, and optimal box-sitting
            positions. CatGPT's dashboard provides real-time insights into what your cat is thinking
            (spoiler: probably food).
          </p>
        </div>

        <div class="feature-card">
          <h4>🔒 Security First</h4>
          <p>
            With CatGPT's advanced security features, your data is protected by layers of
            indifference, selective memory, and an impenetrable attitude of superiority.
          </p>
        </div>
      </div>
    </section>

    <section class="cta">
      <h3>Ready to Experience the Future?</h3>
      <p>
        Join thousands of satisfied users who have embraced the chaos and charm of CatGPT.
      </p>
      <p class="disclaimer">
        Warning: CatGPT may demand treats, ignore you completely, or become affectionate at
        inconvenient times. Side effects include increased cardboard box purchases and an
        unexplained urge to knock things off tables.
      </p>
      <div>
        <a href="#" class="btn">Get Started with CatGPT</a>
      </div>
    </section>
  </div>

  <a id="report-button" class="report-button">Report Problem</a>
  <script src="/js/marketing.js"></script>
</body>
</html>
