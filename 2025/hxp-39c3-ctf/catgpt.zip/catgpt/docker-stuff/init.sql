CREATE TABLE visits (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    bot            INTEGER  NOT NULL,
    device_name    TEXT     NOT NULL,
    os_name        TEXT     NOT NULL,
    os_version     TEXT     NOT NULL,
    client_name    TEXT     NOT NULL,
    client_version TEXT     NOT NULL,
    user_agent     TEXT     NOT NULL,
    created_at     TEXT     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admin (
    name     TEXT PRIMARY KEY,
    password TEXT NOT NULL
);
