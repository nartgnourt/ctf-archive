#!/bin/sh
set -eu

/etc/init.d/php8.4-fpm start

/sbin/ynetd -lm -1 -lt 5 -t 60 -lpid 256 "/home/ctf/admin.py" &

nginx -g 'daemon off;'
