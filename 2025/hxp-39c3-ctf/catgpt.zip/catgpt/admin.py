#!/usr/bin/env python3
import os
import re
import sys
import time

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait

SERVER = 'http://127.0.0.1:80/'

with open("admin.pw", "r") as f:
    PASSWORD = f.read()
if not PASSWORD:
    sys.stdout.write('HTTP/1.1 500 Internal Server Error\r\nConnection: close\r\n\r\nUnknown Password\r\n')
    exit()

# hTtP
start_line = re.match(r'^(?P<method>\S+) /(?P<path>\S*) HTTP/1.[01]$', input().strip())
if not start_line:
    sys.stdout.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\nInvalid Request\r\n')
    exit()

method = start_line.group("method")
if method != "GET":
    sys.stdout.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\nInvalid Request\r\n')
    exit()

path = start_line.group("path")
if path != "":
    sys.stdout.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\nInvalid Path\r\n')
    exit()

print('[+] visiting ', file=sys.stderr)

options = webdriver.ChromeOptions()
options.add_argument('--disable-gpu')
options.add_argument("--headless")
options.add_argument("--disable-dev-shm-usage")
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 10)

driver.get(SERVER + 'login.php')
username_field = driver.find_element('name', 'username')
password_field = driver.find_element('name', 'password')
username_field.send_keys('admin')
password_field.send_keys(PASSWORD)
password_field.submit()

# ensure page has loaded properly
wait.until(lambda driver: driver.execute_script("return document.readyState") == "complete")
time.sleep(5)

driver.quit()

sys.stdout.write('HTTP/1.1 200 OK\r\nConnection: close\r\n\r\nVisited Successfully!')
exit()
