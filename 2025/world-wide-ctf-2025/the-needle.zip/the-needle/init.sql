CREATE TABLE info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    information VARCHAR(255) NOT NULL
);

INSERT INTO info (information) VALUES ('wwf{dummy_flag}');
