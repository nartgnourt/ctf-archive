<?php
// KMACTF{hehe}
?>