from .models import db
from .utils import parse_recepient


def send_mail(to_visible: str, subject: str, body: str) -> str:
    delivery = parse_recepient(to_visible)
    mail = {"to": delivery, "subject": subject,
            "body": body, "visible": to_visible}
    db.add_mail(mail)
    return delivery
