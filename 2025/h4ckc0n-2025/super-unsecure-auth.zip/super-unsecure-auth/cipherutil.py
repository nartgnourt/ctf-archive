from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

def encrypt(user: str) -> str:
    flagpt1 = "d4rk{x_xxxx_xxxx"
    secret = f'{user}{flagpt1}'
    cipher = AES.new(flagpt1.encode(), AES.MODE_ECB)
    #print(secret.encode())
    enc = cipher.encrypt(pad(secret.encode(), 16))
    return enc.hex()