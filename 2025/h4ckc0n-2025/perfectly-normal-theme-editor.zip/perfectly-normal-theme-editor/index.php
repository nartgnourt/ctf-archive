<?php
$dir = __DIR__ . "/templates";
if (!is_dir($dir)) {
    mkdir($dir, 0755, true);
}
$files = array_diff(scandir($dir), ['.', '..']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Template Editor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f6f8fa;
            padding: 40px;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        .file-list {
            list-style: none;
            padding: 0;
        }
        .file-list li {
            background: #fff;
            margin: 5px 0;
            padding: 12px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .file-list a {
            text-decoration: none;
            color: #0366d6;
            font-weight: bold;
        }
        .topbar {
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            padding: 8px 14px;
            background: #28a745;
            color: #fff;
            border-radius: 4px;
            text-decoration: none;
        }
        .btn:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <h1>Template Editor</h1>
    <div class="topbar">
        <a class="btn" href="editor.php">+ Create New Template</a>
    </div>
    <ul class="file-list">
        <?php foreach ($files as $f): ?>
            <?php if (pathinfo($f, PATHINFO_EXTENSION) === 'tpl'): ?>
                <li>
                    <a href="templates/<?= htmlspecialchars($f) ?>" target="_blank">
                        <?= htmlspecialchars($f) ?>
                    </a>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>
</body>
</html>
