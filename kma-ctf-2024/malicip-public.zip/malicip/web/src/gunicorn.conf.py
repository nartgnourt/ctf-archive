
bind = "0.0.0.0:8000"
wsgi_app = "app.app:app"
accesslog = "-"
workers = 2
user = "nobody"
group = "nobody"
