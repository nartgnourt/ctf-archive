import { firefox } from 'playwright'
import { createClient, commandOptions } from 'redis'

const FLAG = process.env.FLAG

if (FLAG.length !== 48) {
  throw new Error('invalid flag')
}

const browser = await firefox.launch()

async function visit(path) {
  const target = new URL(path, process.env.SERVER_BASE_URL).toString()
  const page = await browser.newPage()
  await page.addInitScript(flag => {
    localStorage.setItem('key', flag)
  }, FLAG)
  await page.goto(target, { waitUntil: 'load', timeout: 2000 })
  await page.locator('#generate').click({ timeout: 2000 })
  await page.locator('#result').waitFor({ state: 'visible', timeout: 2000 })
  await page.close()
}

const client = createClient({
  url: process.env.REDIS_URL
})

await client.connect()

let controller = new AbortController()

process.on('SIGTERM', () => {
  controller.abort()
})

while (true) {
  console.log('[*] waiting new query...')
  const { element: path } = await client.blPop(commandOptions({ signal: controller.signal }), 'query', 0)
  const start = Date.now()
  console.log(`[*] start: ${path}`)
  try {
    await visit(path)
  } catch (e) {
    console.error(e.message)
  }
  console.log(`[*] proceeded: ${path} | ${Date.now() - start} msec`)
  await client.incr('proceeded_count')
}
