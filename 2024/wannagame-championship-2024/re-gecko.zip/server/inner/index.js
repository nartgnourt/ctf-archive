const express = require('express');
const http = require('http');
const app = express();
// exp remote pls change re-gecko to service
const RE_GECKO_URL = process.env.RE_GECKO_URL || 'http://re-gecko:8082/';

app.use(express.json());

app.all('*', async (req, res) => {
  try {
    var { method, path, body, headers } = req;
    console.log(method,path,body, headers)
    console.log(path)
     path = path.startsWith('/') ? path.slice(1) : path;
    console.log(path)
    const checkvar = (path) => {
        try {
          if (!path) throw new Error("no path");
          const regex = new RegExp(/^[A-z0-9.\s_-]+$/i);
          if (regex.test(path)) {
            const checked_path = path.replaceAll(/\s/g, "");
            return checked_path;
          } else {
            throw new Error("Error!!");
          }
        } catch (e) {
          console.log(e);
          return "something went wrong";
        }
        };
      path = checkvar(path)
      path = path;

      var re = /flag/i;
      if (re.exec(path)) {
          path = path.replace(re, "");
      }
      
      let url   = new URL(path, RE_GECKO_URL);
    
      const options = {
        method,
        hostname: url.hostname,
        port: url.port,
        path: url.pathname,
        headers: { ...headers, host: url.hostname },
      };
  
      const request = http.request(options, (response) => {
        let data = '';
        response.on('data', (chunk) => {
          data += chunk;
        });
        response.on('end', () => {
          res.status(response.statusCode).send(data);
        });
      });
  
      request.on('error', (error) => {
        console.error('Error forwarding request:', error.message);
        res.status(500).send({ error: 'Failed to forward request' });
      });

  
      request.end();
    } catch (error) {
      console.error('Error forwarding request:', error.message);
      res.status(500).send({ error: 'Failed to forward request' });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Node.js forwarding service is running on port ${PORT}`);
});
