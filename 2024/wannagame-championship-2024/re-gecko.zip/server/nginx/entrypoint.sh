#!/bin/sh

if [ -f /flag ]; then
  echo "set \$flag \"$(cat /flag)\";" > /etc/nginx/flags.conf
else
  echo "set \$flag \"default_flag\";" > /etc/nginx/flags.conf
fi

nginx -g "daemon off;"
