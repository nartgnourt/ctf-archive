from flask import Flask, request, render_template, g, Response, send_file
import sqlite3
from os import environ, path
from random import randbytes, randint
import re

app = Flask(__name__)

con = sqlite3.connect("posts.db", check_same_thread=False)
cursor = con.cursor()
cursor.executescript(f"""
CREATE TABLE posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,  -- Unique identifier for each post
    author TEXT NOT NULL,             -- Name of the author
    content TEXT NOT NULL                -- Content of the blog post
);
                  
INSERT INTO posts (author, content) VALUES ("user", "Today is a very nice day");
INSERT INTO posts (author, content) VALUES ("user", "I wonder how many challenge can I solve today");
INSERT INTO posts (author, content) VALUES ("user", "Maybe I should go touch some grass?");
INSERT INTO posts (author, content) VALUES ("user", "I'm gonna fill all the posts with non-sense texts");
INSERT INTO posts (author, content) VALUES ("user", "Can I leak the admin's note?");
INSERT INTO posts (author, content) VALUES ("admin", "{environ['FLAG'] if 'FLAG' in environ else 'W1{flag}'}");
""")

SECRET_TOKEN = environ["SECRET_TOKEN"] if "SECRET_TOKEN" in environ else randbytes(16).hex()
AUTHENTICATION_TOKEN = "".join([str(randint(0, 9)) for _ in range(64)])
print("DEBUG:", SECRET_TOKEN)
print("DEBUG:", AUTHENTICATION_TOKEN)

CSP = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self'; script-src 'nonce-%s'"

def auth(token):
    tmp = token
    if type(token) == list:
        tmp = "".join(tmp)
    pat = re.compile("^\d+$")
    if pat.match(tmp) == None:
        return False
    for i in range(len(AUTHENTICATION_TOKEN)):
        if int(token[i]) != int(AUTHENTICATION_TOKEN[i]):
            print(token[i], flush=True)
            return False
    return True

@app.before_request
def generate_csp():
    g.nonce = randbytes(16).hex()
    g.csp = ( CSP % g.nonce )

@app.route("/search")
def do_search():
    res = Response()
    res.headers['Content-Security-Policy'] = g.csp
    res.response = render_template("error.html")

    if auth(request.args.get('token', request.args.getlist('token[]'))):
        try:
            keyword = request.args.get('k', "")
            cursor = con.cursor()
            is_admin = False
            if request.cookies.get("SECRET_TOKEN"):
                if request.cookies.get("SECRET_TOKEN") == SECRET_TOKEN:
                    is_admin = True

            posts = cursor.execute("SELECT author, content FROM posts WHERE content like ?", (keyword.replace("%", "").replace("?", "") + "%",)).fetchall()
            
            res.response = render_template("list.html", posts=posts, is_admin=is_admin, nonce=g.nonce)
        except:
            pass
    return res
    
@app.route("/view/<id>")
def do_view(id):
    res = Response()
    res.headers['Content-Security-Policy'] = g.csp

    try:
        if not auth(request.args.get('token', request.args.getlist('token[]'))):
            res.response = render_template("error.html")
        cursor = con.cursor()

        cursor.execute("SELECT author, content FROM posts WHERE id = ? and author != 'admin'", (id,))
        author, content = cursor.fetchone()
        res.response = render_template("view.html", author=author, content=content)
    except:
        res.response = render_template("error.html")
    return res
    
@app.route("/")
def do_list():
    res = Response()
    res.headers['Content-Security-Policy'] = g.csp

    cursor.execute("SELECT author, content FROM posts")
    posts = cursor.fetchall()
    res.response = render_template("list.html", posts=posts, is_admin=False, nonce=g.nonce)
    
    return res

@app.route('/static/<f_path>')
def serve_static(f_path):
    f_path = f_path.replace("_", "/")
    if "posts" in f_path or "proc" in f_path or "fd" in f_path:
        return ""
    return send_file(path.join('static/', f_path))

if __name__ == '__main__':
    app.run("0.0.0.0", 1337, debug=False)