#!/usr/bin/env node
const express = require('express')
const childProcess = require('child_process');
const util = require('util');
const dns = require('dns')
const fs = require('fs')
const lookup = util.promisify(dns.lookup);

const app = express();

app.use(express.static('./static'));
app.use(express.urlencoded({ extended: false }));

(async () => {
	const domain = process.env.WEB_DOMAIN ?? (console.log("no WEB_DOMAIN env"),exit(1));
	const {address:ip} = await lookup(domain);
	console.log(ip)
	fs.writeFileSync("/app/static/ip.txt", ip);
})()


app.post('/report',(req,res)=>{
	let url = req.body.url?.toString();

	res.type('text/plain');
	if(url && (url.startsWith('http://') || url.startsWith('https://'))){
		childProcess.spawn('node',['./bot.js',JSON.stringify(url)]);
    	res.send('Admin will visit!');
	} else {
		res.send('Bad params');
	}
});

app.listen(8000);
