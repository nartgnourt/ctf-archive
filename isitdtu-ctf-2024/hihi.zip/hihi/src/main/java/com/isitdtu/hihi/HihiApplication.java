package com.isitdtu.hihi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HihiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HihiApplication.class, args);
	}

}
