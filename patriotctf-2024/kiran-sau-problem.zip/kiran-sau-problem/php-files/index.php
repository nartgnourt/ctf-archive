<html>
<head>
<title>Kiran Sau Problem</title>
</head>
</html>

<?php

echo "Welcome to the world of CTF";

?>
