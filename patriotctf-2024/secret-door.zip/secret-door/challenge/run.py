from app import app

app.run(host='0.0.0.0', port=1337, debug=False, use_evalex=False)